// (c) 2009 Uri Wilensky. See README.txt for terms of use.

package org.nlogo.lab.gui

import org.nlogo.api.Dump
import org.nlogo.api.{CompilerException,CompilerServices,Editable,LogoList,PropertyDescription}
import org.nlogo.lab.{EnumeratedValueSet,Protocol,SteppedValueSet,ValueSet}
import java.awt.{GridBagConstraints,Window}

// normally we'd be package-private but the org.nlogo.properties stuff requires we be public - ST 2/25/09

class ProtocolEditable(protocol: Protocol,
                       window: Window,
                       compiler: CompilerServices,
                       worldLock: AnyRef)
  extends Editable
{
  // these are for Editable
  val classDisplayName = "Experiment"
  val error = null
  val errorProperty = null
  val sourceOffset = 0
  import org.nlogo.util.JCL.seqToJavaList
  val propertySet: java.util.List[PropertyDescription] =
    List(new PropertyDescription("name", "Experiment name", "String", GridBagConstraints.REMAINDER, true),
         new PropertyDescription("valueSets",
                                 "Vary variables as follows (note brackets and quotation marks):",
                                 "<html>Either list values to use, for example:<br>" +
                                 "  [\"my-slider\" 1 2 7 8]<br>" +
                                 "or specify start, increment, and end, for example:<br>" +
                                 "  [\"my-slider\" [0 1 10]] (note additional brackets)<br>" +
                                 "to go from 0, 1 at a time, to 10.<br>" +
                                 "You may also vary max-pxcor, min-pxcor, max-pycor, min-pycor, random-seed.</html>",
                                 "ReporterOrEmpty", GridBagConstraints.REMAINDER, false),
         new PropertyDescription("repetitions", "Repetitions", "<html>run each combination this many times</html>",
                                 "Integer", GridBagConstraints.REMAINDER, false),
         new PropertyDescription("metrics", "Measure runs using these reporters:",
                                 "<html>one reporter per line; you may not split a reporter<br>" +
                                 "across multiple lines</html",
                                 "ReporterOrEmpty", GridBagConstraints.REMAINDER, false),
         new PropertyDescription("runMetricsEveryStep", "Measure runs at every step",
                                 "<html>if unchecked, runs are measured only when they are over</html>",
                                 "Boolean", GridBagConstraints.REMAINDER, false),
         new PropertyDescription("setupCommands", "Setup commands:", "Commands", GridBagConstraints.RELATIVE, false),
         new PropertyDescription("goCommands", "Go commands:", "Commands", GridBagConstraints.REMAINDER, false),
         new PropertyDescription("exitCondition", "Stop condition:",
                                 "<html>the run stops if this reporter becomes true</html>",
                                 "ReporterOrEmpty", GridBagConstraints.RELATIVE, false),
         new PropertyDescription("finalCommands", "Final commands:",
                                 "<html>run at the end of each run</html>",
                                 "Commands", GridBagConstraints.REMAINDER, false),
         new PropertyDescription("timeLimit", "Time limit",
                                 "<html>stop after this many steps (0 = no limit)</html>",
                                 "Integer", GridBagConstraints.REMAINDER, false))
  // These are the actual vars the user edits.  Before editing they are copied out of the
  // original Protocol; after editing a new Protocol is created.
  var name = protocol.name
  var setupCommands = protocol.setupCommands
  var goCommands = protocol.goCommands
  var finalCommands = protocol.finalCommands
  var repetitions = protocol.repetitions
  var runMetricsEveryStep = protocol.runMetricsEveryStep
  var timeLimit = protocol.timeLimit
  var exitCondition = protocol.exitCondition
  var metrics = protocol.metrics.mkString("\n")
  var valueSets =  {
    def setString(valueSet: ValueSet) =
      "[\"" + valueSet.variableName + "\" " +
      (valueSet match {
         case evs: EnumeratedValueSet =>
           evs.map(Dump.logoObject(_, true, false)).mkString(" ")
         case svs: SteppedValueSet =>
           List(svs.first, svs.step, svs.last).map(Dump.number(_)).mkString("[", " ", "]")
       }) + "]\n"
    protocol.valueSets.map(setString).mkString
  }
  // make a new Protocol based on what user entered
  def editFinished: Boolean = get.isDefined
  def get: Option[Protocol] = {
    def complain(message: String) {
      javax.swing.JOptionPane.showMessageDialog(
        window, "Invalid spec for varying variables. Error:\n" + message,
       "Invalid", javax.swing.JOptionPane.ERROR_MESSAGE)
    }
    Some(new Protocol(
      name.trim, setupCommands.trim, goCommands.trim,
      finalCommands.trim, repetitions, runMetricsEveryStep,
      timeLimit, exitCondition.trim,
      metrics.split("\n", 0).map(_.trim).filter(!_.isEmpty).toList,
      {
        val list =
          try { worldLock.synchronized {
            compiler.readFromString("[" + valueSets + "]").asInstanceOf[LogoList]
          } }
        catch{ case ex: CompilerException => complain(ex.getMessage); return None }
        import org.nlogo.util.JCL._ // so we can access LogoLists
        for(o <- list.toList) yield {
          o.asInstanceOf[LogoList].toList match {
            case List(variableName: String, more: LogoList) =>
              more.toList match {
                case List(first: java.lang.Double,
                          step: java.lang.Double,
                          last: java.lang.Double) =>
                  new SteppedValueSet(variableName,
                                      first.doubleValue,
                                      step.doubleValue,
                                      last.doubleValue)
                case _ =>
                  complain("Expected three numbers here: " + Dump.list(more)); return None
              }
            case List(variableName: String, more@_*) =>
              new EnumeratedValueSet(variableName, more.toList)
            case _ =>
              complain("Invalid format"); return None
          }}
      }))
  }
}

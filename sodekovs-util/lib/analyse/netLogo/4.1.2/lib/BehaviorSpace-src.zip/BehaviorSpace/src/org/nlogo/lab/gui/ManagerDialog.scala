// (c) 2009 Uri Wilensky. See README.txt for terms of use.

package org.nlogo.lab.gui

import org.nlogo.lab.{EnumeratedValueSet,Protocol}
import org.nlogo.window.EditDialogFactoryInterface
import javax.swing.{JButton,JDialog,JLabel,JList,JOptionPane,JPanel,JScrollPane}

private class ManagerDialog(manager: LabManager,
                            dialogFactory: EditDialogFactoryInterface)
  extends JDialog(manager.workspace.getFrame)
  with javax.swing.event.ListSelectionListener
{
  private val jlist = new JList
  private val listModel = new javax.swing.DefaultListModel
  /// actions
  private def action(name: String, fn: ()=>Unit) =
    new javax.swing.AbstractAction(name) {
      def actionPerformed(e: java.awt.event.ActionEvent) { fn() } }
  private val editAction = action("Edit", edit _)
  private val newAction = action("New", makeNew _)
  private val deleteAction = action("Delete", delete _)
  private val duplicateAction = action("Duplicate", duplicate _)
  private val closeAction = action("Close", manager.close _)
  private val runAction = action("Run", run _)
  /// initialization
  init()
  private def init() {
    setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE)
    addWindowListener(new java.awt.event.WindowAdapter {
      override def windowClosing(e: java.awt.event.WindowEvent) { closeAction.actionPerformed(null) } })
    setTitle("BehaviorSpace")
    // set up the list
    jlist.putClientProperty("Quaqua.List.style", "striped")
    jlist.setVisibleRowCount(5)
    jlist.setModel(listModel)
    jlist.addListSelectionListener(this)
    // Listen for double-clicks, and edit the selected protocol
    jlist.addMouseListener(new javax.swing.event.MouseInputAdapter {
      override def mouseClicked(e: java.awt.event.MouseEvent) {
        if(e.getClickCount > 1) edit() } })
    // Setup the first row of buttons
    val buttonPanel = new JPanel
    val runButton = new JButton(runAction)
    buttonPanel.setLayout(new javax.swing.BoxLayout(buttonPanel, javax.swing.BoxLayout.X_AXIS))
    buttonPanel.add(javax.swing.Box.createHorizontalGlue)
    buttonPanel.add(javax.swing.Box.createHorizontalStrut(20))
    buttonPanel.add(new JButton(newAction))
    buttonPanel.add(javax.swing.Box.createHorizontalStrut(5))
    buttonPanel.add(new JButton(editAction))
    buttonPanel.add(javax.swing.Box.createHorizontalStrut(5))
    buttonPanel.add(new JButton(duplicateAction))
    buttonPanel.add(javax.swing.Box.createHorizontalStrut(5))
    buttonPanel.add(new JButton(deleteAction))
    buttonPanel.add(javax.swing.Box.createHorizontalStrut(5))
    buttonPanel.add(runButton)
    buttonPanel.add(javax.swing.Box.createHorizontalStrut(20))
    buttonPanel.add(javax.swing.Box.createHorizontalGlue)
    val listLabel = new JLabel("Experiments:")
    // layout
    buttonPanel.setBorder(new javax.swing.border.EmptyBorder(8, 0, 8, 0))
    listLabel.setBorder(new javax.swing.border.EmptyBorder(8, 0, 0, 0))
    getContentPane.setLayout(new java.awt.BorderLayout(0, 10))
    getContentPane.add(listLabel, java.awt.BorderLayout.NORTH) 
    getContentPane.add(new JScrollPane(jlist), java.awt.BorderLayout.CENTER)
    getContentPane.add(buttonPanel, java.awt.BorderLayout.SOUTH)
    pack()
    // set location
    val maxBounds = getGraphicsConfiguration.getBounds
    setLocation(maxBounds.x + maxBounds.width / 3,
                maxBounds.y + maxBounds.height / 2)
    // misc
    org.nlogo.swing.Utils.addEscKeyAction(this, closeAction)
    getRootPane.setDefaultButton(runButton)
  }
  /// implement ListSelectionListener
  def valueChanged(e: javax.swing.event.ListSelectionEvent) {
    val count = jlist.getSelectedIndices.length
    editAction.setEnabled(count == 1)
    duplicateAction.setEnabled(count == 1)
    runAction.setEnabled(count == 1)
    deleteAction.setEnabled(count > 0)
  }
  /// action implementations
  private def run() {
    try {
      manager.prepareForRun()
      new Supervisor(this, manager.workspace, selectedProtocol, manager.workspaceFactory, dialogFactory).start()
    }
    catch { case ex: org.nlogo.awt.UserCancelException => org.nlogo.util.Exceptions.ignore(ex) }
  }
  private def makeNew {
    import org.nlogo.util.JCL._ // interfaceGlobals is a Java list
    editProtocol(
      new Protocol(
        "experiment", "setup", "go", "", 1, true, 0, "", List("count turtles"),
        manager.workspace.world.synchronized {
          // We should be able to just write "program" instead of "program()" in the next
          // line, but this fails with an IllegalAccessException as of Scala 2.7.2.RC6.
          // https://lampsvn.epfl.ch/trac/scala/ticket/1240 - ST 9/25/08
          manager.workspace.world.program().interfaceGlobals.toList
          .map{case variableName: String =>
            new EnumeratedValueSet(
              variableName, List(manager.workspace.world.getObserverVariableByName(variableName)))}}),
      true)
  }
  private def duplicate() { editProtocol(selectedProtocol, true) }
  private def edit() { editProtocol(selectedProtocol, false) }
  private def editProtocol(protocol: Protocol, isNew: Boolean) {
    val editable = new ProtocolEditable(protocol, manager.workspace.getFrame, 
                                        manager.workspace, manager.workspace.world)
    if(!dialogFactory.canceled(this, editable, false, manager.workspace, manager.editorColorizer)) {
      val newProtocol = editable.get.get
      if(isNew) manager.protocols += newProtocol
      else manager.protocols(selectedIndex) = newProtocol
      update()
      select(newProtocol)
      manager.dirty()
    }
  }
  private def delete() {
    val selected = jlist.getSelectedIndices
    val message = "Are you sure you want to delete " +
      (if(selected.length > 1) "these " + selected.length + " experiments?"
       else "\"" + listModel.getElementAt(selected(0)).asInstanceOf[Protocol].name + "\"?")
    if(JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(this, message, "Delete", JOptionPane.YES_NO_OPTION)) {
      for(i <- 0 until selected.length)
        manager.protocols -= listModel.getElementAt(selected(i)).asInstanceOf[Protocol]
      update()
      // it's annoying if nothing is left selected, so select something
      val newSize = manager.protocols.size
      if(newSize > 0) select(if(selected(0) >= newSize) (selected(0) - 1) min (newSize - 1)
                             else selected(0))
      manager.dirty()
    }
  }
  /// helpers
  def update() {
    listModel.clear
    manager.protocols.foreach(listModel.addElement(_))
    valueChanged(null)
    if(manager.protocols.size > 0) jlist.setSelectedIndices(Array(0))
  }
  private def select(index: Int) {
    jlist.setSelectedIndices(Array(index))
    jlist.ensureIndexIsVisible(index)
  }
  private def select(targetProtocol: Protocol) {
    val index = manager.protocols.findIndexOf(_ eq targetProtocol)
    jlist.setSelectedIndices(Array(index))
    jlist.ensureIndexIsVisible(index)
  }
  private def selectedIndex =
    jlist.getSelectedIndices match { case Array(i: Int) => i }
  private def selectedProtocol =
    manager.protocols(jlist.getSelectedIndices()(0))
}

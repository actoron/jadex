// (c) 2009 Uri Wilensky. See README.txt for terms of use.

package org.nlogo.lab

import org.junit.Assert._
import org.junit.Test
import org.nlogo.nvm.{CompilerInterface,DefaultCompilerServices}
import org.nlogo.util.Femto
import org.xml.sax.SAXException
import scala.collection.mutable.ListBuffer

class TestLoadAndSave { 
  val loader = new ProtocolLoader(
    new DefaultCompilerServices(
      Femto.scalaSingleton(classOf[CompilerInterface],
                           "org.nlogo.compiler.Compiler")))
  @Test def testLoadAndSave() {
    val protocols = loader.loadAll(new java.io.File("test/lab/protocols.xml"))
    assertEquals(org.nlogo.api.FileIO.file2String("test/lab/protocols.xml").replaceAll("\r\n","\n"),
                 "<?xml version=\"1.0\" encoding=\"us-ascii\"?>" + "\n" +
                 ProtocolLoader.DOCTYPE + "\n" +
                 ProtocolSaver.save(protocols))
  }
  @Test def testBadXML1() {
    val xml = org.nlogo.api.FileIO.file2String("test/lab/protocols.xml")
      .replaceFirst("^<\\?xml.*\\n","")
      .replaceFirst("<!DOCTYPE.*\\n","")
    val badXml = xml.replaceFirst("</metric>", "</mertic>")
    assertFalse(xml == badXml)
    try {
      loader.loadAll(badXml)
      fail()
    }
    catch {
      case ex:SAXException =>
        // error message may vary on different VM's, so use a regex
        assertTrue(Set("Expected \"</metric>\" to terminate element starting on line 11.",
                       "The element type \"metric\" must be terminated by the matching end-tag \"</metric>\".",
                       "XML declaration may only begin entities.",
                       "The processing instruction target matching \"[xX][mM][lL]\" is not allowed.")
                   .contains(ex.getMessage))
    }
  }
  @Test def testBadXML2() {
    val xml = org.nlogo.api.FileIO.file2String("test/lab/protocols.xml")
      .replaceFirst("^<\\?xml.*\\n","")
      .replaceFirst("<!DOCTYPE.*\\n","")
    val badXml = xml.replaceAll("metric","mertic")
    assertFalse(xml == badXml)
    try {
      loader.loadAll(badXml)
      fail()
    }
    catch {
      case ex:SAXException =>
        // error message may vary on different VM's, so use a regex
        assertTrue(Set("Element \"experiment\" does not allow \"mertic\" here.",
                       "Element type \"mertic\" must be declared.",
                         "XML declaration may only begin entities.",
                       "The processing instruction target matching \"[xX][mM][lL]\" is not allowed.")
                   .contains(ex.getMessage))
    }
  }
  @Test def testBadXML3() {
    try {
      loader.loadAll(new java.io.File("test/lab/bad.xml"))
      fail()
    }
    catch {
      case ex:java.io.FileNotFoundException =>
        assertTrue(ex.getMessage().matches(".*bespaviorhace\\.dtd.*"))
    }
  }
}

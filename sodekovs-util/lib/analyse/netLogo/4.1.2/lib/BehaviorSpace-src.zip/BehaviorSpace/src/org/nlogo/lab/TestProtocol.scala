// (c) 2009 Uri Wilensky. See README.txt for terms of use.

package org.nlogo.lab

import org.junit.Assert._
import org.junit.Test

class TestProtocol
{
  @Test def empty1() {
    val protocol = new Protocol("", "", "", "", 1, true, 0, "", Nil, Nil)
    assertEquals(1, protocol.countRuns)
    assertEquals("List()", protocol.elements.mkString(" "))
  }
  @Test def empty2() {
    val protocol = new Protocol("", "", "", "", 5, true, 0, "", Nil, Nil)
    assertEquals(5, protocol.countRuns)
    assertEquals("List() List() List() List() List()", protocol.elements.mkString(" "))
  }
  @Test def enumerated1() {
    val protocol =
      new Protocol("", "", "", "", 1, true, 0, "", Nil,
                   List(new EnumeratedValueSet("foo", List(1d, 2d, 3d))))
    assertEquals(3, protocol.countRuns)
    assertEquals("List((foo,1.0)) List((foo,2.0)) List((foo,3.0))",
                 protocol.elements.mkString(" "))
  }
  @Test def enumerated2() {
    val protocol =
      new Protocol("enumerated2", "", "", "", 2, true, 0, "", Nil,
                   List(new EnumeratedValueSet("foo", List(1d, 2d, 3d))))
    assertEquals(6, protocol.countRuns)
    assertEquals("List((foo,1.0)) List((foo,1.0)) List((foo,2.0)) List((foo,2.0)) List((foo,3.0)) List((foo,3.0))",
                 protocol.elements.mkString(" "))
    assertEquals("enumerated2 (6 runs)", protocol.toString)
  }
  @Test def stepped1() {
    val protocol = new Protocol("", "", "", "", 1, true, 0, "", Nil,
                                List(new SteppedValueSet("foo", 1d, 1d, 5d)))
    assertEquals(5, protocol.countRuns)
    assertEquals("List((foo,1.0)) List((foo,2.0)) List((foo,3.0)) List((foo,4.0)) List((foo,5.0))",
                 protocol.elements.mkString(" "))
  }
  @Test def stepped2() {
    val protocol = new Protocol("stepped2", "", "", "", 10, true, 0, "", Nil,
                                List(new SteppedValueSet("foo", 1d, 1d, 5d)))
    assertEquals(50, protocol.countRuns)
    assertEquals("stepped2 (50 runs)", protocol.toString)
  }
  @Test def both() {
    def make(repetitions:Int) =
      new Protocol("both", "", "", "", repetitions, true, 0, "", Nil,
                   List(new EnumeratedValueSet("foo", List(1d, 2d, 3d)),
                        new SteppedValueSet("bar", 1d, 1d, 5d)))
    val protocol1 = make(1)
    assertEquals(15, protocol1.countRuns)
    assertEquals(
      "List((foo,1.0), (bar,1.0)) List((foo,1.0), (bar,2.0)) List((foo,1.0), (bar,3.0)) " +
      "List((foo,1.0), (bar,4.0)) List((foo,1.0), (bar,5.0)) List((foo,2.0), (bar,1.0)) " +
      "List((foo,2.0), (bar,2.0)) List((foo,2.0), (bar,3.0)) List((foo,2.0), (bar,4.0)) " +
      "List((foo,2.0), (bar,5.0)) List((foo,3.0), (bar,1.0)) List((foo,3.0), (bar,2.0)) " +
      "List((foo,3.0), (bar,3.0)) List((foo,3.0), (bar,4.0)) List((foo,3.0), (bar,5.0))",
      protocol1.elements.mkString(" "))
    assertEquals(45, make(3).countRuns)
  }
}

#!/bin/sh -e -v

JAVA='java -Djava.awt.headless=true'

$JAVA -classpath BehaviorSpace.jar:../../NetLogo.jar:../junit.jar org.junit.runner.JUnitCore org.nlogo.lab.AllTests
$JAVA -classpath BehaviorSpace.jar:../../NetLogo.jar:../junit.jar org.junit.runner.JUnitCore org.nlogo.lab.gui.AllTests

// (c) 2009 Uri Wilensky. See README.txt for terms of use.

package org.nlogo.lab

import org.junit.runner.RunWith
import org.junit.runners.Suite
import org.junit.runners.Suite.SuiteClasses

// This package has few tests of its own.  Most of the real testing of the functionality of
// BehaviorSpace happens over in org.nlogo.headless.TestBehaviorSpace. - ST 7/10/09

@RunWith(classOf[Suite])
@SuiteClasses(Array(classOf[TestProtocol],
                    classOf[TestLoadAndSave]))
class AllTests

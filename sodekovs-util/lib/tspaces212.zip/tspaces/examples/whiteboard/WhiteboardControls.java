// WhiteboardControls.java

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

package	com.ibm.tspaces.examples.whiteboard;

import java.awt.event.*;
import java.awt.*;
import java.applet.*;
import java.util.Vector;

/**
** The controls for the whiteboard.
** 
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:40 $
** @author <a href="mailto:eichstam@almaden.ibm.com">Matthias Eichstaedt</a>
*/
public class WhiteboardControls extends Panel implements ItemListener, ActionListener {

    WhiteboardPanel target;
	private static String PUBLISH_CMD = "Publish";
	private static String ERASE_CMD = "Erase";	
	private static String ERASEALL_CMD = "EraseAll";
  private static String EXIT_CMD = "Exit";


	private Button publishButton = null;
	private Button eraseButton = null;
	private Button eraseAllButton = null;
  private Button exitButton = null;
    /*
    ***************************************************************************
    ** ** WhiteboardControls **
    ** ************************
    */
    /**
    ** The constructor.
    **
    ** @param target - the whiteboard panel
    *************************************************************************** 
    */
    public WhiteboardControls(Panel target) {
        
        this.target = (WhiteboardPanel)target;
        Panel pLine1 = new Panel();
        Panel pLine2 = new Panel();
        setLayout(new GridLayout(2,1));
        add(pLine1);
        add(pLine2);
        
        pLine1.setLayout(new FlowLayout());
        publishButton = new Button();
        publishButton.setLabel(PUBLISH_CMD);
        publishButton.addActionListener(this);
        pLine1.add(publishButton);
        eraseButton = new Button();
        eraseButton.setLabel(ERASE_CMD);
        eraseButton.addActionListener(this);
        pLine1.add(eraseButton);
        eraseAllButton = new Button();
        eraseAllButton.setLabel(ERASEALL_CMD);
        eraseAllButton.addActionListener(this);
        pLine1.add(eraseAllButton);
        exitButton = new Button();
        exitButton.setLabel(EXIT_CMD);
        exitButton.addActionListener(this);
        pLine1.add(exitButton);


        pLine1.setBackground(Color.lightGray);
        pLine2.setBackground(Color.lightGray);
                
        target.setForeground(Color.red);
        CheckboxGroup group = new CheckboxGroup();
        Checkbox b;
        pLine2.add(b = new Checkbox(null, group, false));
        b.addItemListener(this);
        b.setBackground(Color.red);
        pLine2.add(b = new Checkbox(null, group, false));
        b.addItemListener(this);
        b.setBackground(Color.green);
        pLine2.add(b = new Checkbox(null, group, false));
        b.addItemListener(this);
        b.setBackground(Color.blue);
        pLine2.add(b = new Checkbox(null, group, false));
        b.addItemListener(this);
        b.setBackground(Color.pink);
        pLine2.add(b = new Checkbox(null, group, false));
        b.addItemListener(this);
        b.setBackground(Color.orange);
        pLine2.add(b = new Checkbox(null, group, true));
        b.addItemListener(this);
        b.setBackground(Color.black);
        target.setForeground(b.getForeground());
        Choice shapes = new Choice();
        shapes.addItemListener(this);
        shapes.addItem("Lines");
        shapes.addItem("Points");
        shapes.setBackground(Color.lightGray);
        pLine2.add(shapes);
    } // WhiteboardControls

    /*
    ***************************************************************************
    ** ** paint **
    ** ***********
    */
    /**
    ** Paints me.
    **
    ** @param g - a graphics context
    *************************************************************************** 
    */
    public void paint(Graphics g) {
        Rectangle r = getBounds();

        g.setColor(Color.lightGray);
        g.draw3DRect(0, 0, r.width, r.height, false);
    } // paint

    /*
    ***************************************************************************
    ** ** itemStateChanged **
    ** **********************
    */
    /**
    ** The state of the item was changed.
    **
    ** @param e - the item event
    *************************************************************************** 
    */
    public void itemStateChanged(ItemEvent e) {
        if (e.getSource() instanceof Checkbox) {
            target.setForeground(((Component)e.getSource()).getBackground());
        } else if (e.getSource() instanceof Choice) {
            String choice = (String) e.getItem();
            if (choice.equals("Lines")) {
                target.setDrawMode(WhiteboardPanel.LINES);
            } else if (choice.equals("Points")) {
                target.setDrawMode(WhiteboardPanel.POINTS);
            } // if
        } // if
    } // itemStateChanged

    /*
    ***************************************************************************
    ** ** actionPerformed **
    ** *********************
    */
    /**
    ** A button was pushed. It will call the appropriate method
    ** in the WhiteboardPanel
    **
    ** @param e - the action event
    *************************************************************************** 
    */
    public void actionPerformed(ActionEvent e) {
    	System.out.println("Action="+e.getActionCommand());
    	// Send to target
    	//    target is the WhiteboardPanel class
    	if (e.getActionCommand().equals(PUBLISH_CMD))
        	target.publish();
        else if (e.getActionCommand().equals(ERASE_CMD)) 
        	target.erase();
        else if (e.getActionCommand().equals(ERASEALL_CMD)) 
        	target.eraseAll();
        else if (e.getActionCommand().equals(EXIT_CMD)) 
          target.exitcmd();

        	
	
    } // actionPerformed
    
     /*
    ***************************************************************************
    ** ** setPublish **
    ** *********************
    */
    /**
    ** allow the Publish button to be enabled/disabled.
    **
    ** @param e - the action event
    *************************************************************************** 
    */
    public void setPublish(boolean state) {
    	
    	publishButton.setEnabled(state);
    
    		    	
    } // setPublish
 /*
    ***************************************************************************
    ** ** setErase **
    ** *********************
    */
    /**
    ** allow the Erase button to be enabled/disabled.
    **
    ** @param e - the action event
    *************************************************************************** 
    */
    public void setErase(boolean state) {
    	
    	eraseAllButton.setEnabled(state);
    
    		    	
    } // setErase

} // WhiteboardControls

/*
$History: WhiteboardControls.java $
 * 
 * *****************  Version 1  *****************
 * User: Toby         Date: 1/23/98    Time: 9:56a
 * Created in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/whiteboard
 * 
 * *****************  Version 9  *****************
 * User: Jthomas      Date: 1/05/98    Time: 2:21p
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces/examples/whiteboard
 * Replace Erase button with Erase/EraseAll 
 * Bypass the Vector Serialization bug
 * 
 * *****************  Version 8  *****************
 * User: Jthomas      Date: 11/29/97   Time: 12:27p
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces/examples/whiteboard
 * Add setPublish and setErase methods
 * 
 * *****************  Version 7  *****************
 * User: Jthomas      Date: 11/26/97   Time: 4:41p
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces/examples/whiteboard
 * Whiteboard - fix for browsers that don't support JDK 1.1
 * 
 * *****************  Version 6  *****************
 * User: Jthomas      Date: 11/24/97   Time: 10:48a
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces/examples/whiteboard
 * Lots of changes:
 *    Moved all TupleSpace code to WhiteboardPanel
 *    Added Erase feature
 *    Only write new Lines and points to TS
 *    Handle host/port
 *    misc
 * 
 * *****************  Version 5  *****************
 * User: Jthomas      Date: 11/18/97   Time: 10:25a
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces/examples/whiteboard
 * Changes so that it works as an applet and an application
 * 
 * *****************  Version 4  *****************
 * User: Toby         Date: 10/02/97   Time: 6:38p
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces/examples/whiteboard
 * Changed most of these (copypaste thru Rhonda) to the new lower case com
 * model.  Also cleaned up a few deprecated APIs and got some old stuff
 * working (or at least commented out).  Will be back for the remaining
 * examples sometime later.
 * 
 * *****************  Version 2  *****************
 * User: Eichstam     Date: 8/12/97    Time: 6:34p
 * Updated in $/GCS/Development/Java/COM/ibm/almaden/tuplespace/examples/whiteboard
 * added the callback mechanism
 * 
 * *****************  Version 1  *****************
 * User: Eichstam     Date: 7/18/97    Time: 1:25a
 * Created in $/GCS/Development/Java/COM/ibm/almaden/tuplespace/examples/whiteboard
 * initial version of the GCS 'shared' whiteboard
*/

	


    
/* $Log: WhiteboardControls.java,v $
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.3  1999/09/26 07:54:34  jthomas
 * Modify so it looks better on the Nino PDA
 *
 * Revision 1.2  1999/06/17 05:39:47  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */


package com.ibm.tspaces.examples.helloworld;

import com.ibm.tspaces.*;
import java.io.Serializable;

/** 
** SubclassableTuple that represents a Message Tuple
** that contains:
**   Field 0  --- Destination (String)
**   Field 1  --- From  (String)
**   Field 2  --- Message  (any Serialized object)
**
** @see SubclassableTuple
** @see Field
** @author  John Thomas
** @version     $Revision: 1.1.2.1 $ $Date: 1999/11/09 18:53:31 $
*/
public class Message extends SubclassableTuple {
  
  
  /**
  ** Default Constructor
  */
  public Message() throws TupleSpaceException {
    super(new Field(String.class),new Field(String.class),new Field(Serializable.class));
  }
  
  /**
  ** Constructor that will generate a Template for searching space 
  ** for Message objects that are "to" the specified name.
  ** @param to  The destination name.
  */
  public Message(String to) throws TupleSpaceException {
    super(to,new Field(String.class), new Field(Serializable.class));
  }
  
  /**
  ** Constructor that will generate a Message that will be written
  ** to the space.
  **
  ** @param to  The destination name.
  ** @param from  The name of the source.
  ** @param message The Object being sent as a message. 
  */
  public Message(String to,String from, Serializable message) throws TupleSpaceException {
    super(to, from, message);           
          
  }

  
  /**
  ** Accessor method for a Field in the SuperTuple.
  */
  public String getDestination() throws TupleSpaceException{    
    return (String)getField(0).getValue();  
  }
  
  /**
  ** Setter method for a Field in the SuperTuple.
  */
  public void setDestination(String to) throws TupleSpaceException{         
       getField(0).setValue(to);         
  }
  
  /**
  ** Accessor method for a Field in the SuperTuple.
  */
  public String getFrom() throws TupleSpaceException{    
    return (String)getField(1).getValue();
  }
  
  /**
  ** Setter method for a Field in the SuperTuple.
  */
  public void setFrom(String to) throws TupleSpaceException{         
       getField(1).setValue(to);
  }
  
  /**
  ** Accessor method for a Field in the SuperTuple.
  */
  public Serializable getMessage() throws TupleSpaceException{         
      return getField(2).getValue();
  }
  
  /**
  ** Setter method for a Field in the SuperTuple.
  */
  public void setMessage(Serializable message) throws TupleSpaceException{    
      getField(2).setValue(message);    
  }

}
package com.ibm.tspaces.examples.helloworld;

import com.ibm.tspaces.*;

/**
** A simple message passing example.
** This class will get it's name from the command line and then 
** check if anyone has sent it a message.  If so, it will reply to it.
** If there is no message waiting, it will send a message to "World".
**
** @author  John Thomas
** @version     $Revision: 1.1.2.1 $ $Date: 1999/11/09 18:53:31 $
*/
public class HelloWorld {
  
  /**
  **
  */
  public static void main(String[] args) {
    String myName = "World";
    boolean needReply = false;
    
    if ( args.length > 0) 
      myName = args[0];
    
    try {
      TupleSpace space = new TupleSpace();
      
      Message template = new Message(myName);
      // see if I have a message waiting 
      Message msg = (Message)space.take(template);
      System.out.println(msg);
      if ( msg == null) {        
        msg = new Message("World", myName,"Hello World"); 
        needReply = true;
      } else {
        msg = new Message(msg.getFrom(),myName,"Hi");
      }            
      space.write(msg);      
      
      
      if (needReply) { // Wait for a reply      
        msg = (Message)space.waitToTake(template);
        System.out.println(msg);
      }
      
    } catch (Exception e) {
        System.out.println(e);
        //e.printStackTrace();
    }
  }
}
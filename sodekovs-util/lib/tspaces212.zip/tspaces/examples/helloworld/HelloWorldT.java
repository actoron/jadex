package com.ibm.tspaces.examples.helloworld;

import com.ibm.tspaces.*;
import java.io.Serializable;

/**
** A simple message passing example.
** This class will get it's name from the command line and then 
** check if anyone has sent it a message.  If so, it will reply to it.
** If there is no message waiting, it will send a message to "World".
**
** HelloWorldT is a variation of the HelloWorld class that does not 
** use a Message class. Instead it writes Tuple Objects and manipulates 
** the internal Fields itself.  
** 
** @author  John Thomas
** @version     $Revision: 1.1.2.1 $ $Date: 1999/11/09 18:53:31 $
*/
public class HelloWorldT {
  
  /**
  **
  */
  public static void main(String[] args) {
    String myName = "World";
    boolean needReply = false;
    
    if ( args.length > 0) 
      myName = args[0];
    
    try {
      TupleSpace space = new TupleSpace();
      
      Tuple template = new Tuple(myName,
              new Field(String.class),new Field(Serializable.class));
      // see if I have a message waiting 
      Tuple msg = space.take(template);
      System.out.println(msg);
      if ( msg == null) {        
        msg = new Tuple("World", myName,"Hello World"); 
        needReply = true;
      } else {
        msg = new Tuple((String)msg.getField(1).getValue(),myName,"Hi");
      }            
      space.write(msg);      
      
      
      if (needReply) { // Wait for a reply      
        msg = space.waitToTake(template);
        System.out.println(msg);
      }
      
    } catch (Exception e) {
        System.out.println(e);
        //e.printStackTrace();
    }
  }
}
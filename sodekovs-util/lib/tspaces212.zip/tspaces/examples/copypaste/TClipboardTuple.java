// TClipboardTuple.java

package com.ibm.tspaces.examples.copypaste;

import  java.util.*;
import  com.ibm.tspaces.*;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

/**
** This class represents a subclass of tuple that is
** (1) The tuplespace name
** (2) The user name
** (3) The buffer number
** (4) The cut/paste buffer data.
**
** @see Tuple
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:38 $
** @author Matthias Eichstaedt
** @author Toby Lehman
** @author Steve McLaughry
*/

public class TClipboardTuple extends SubclassableTuple {

  /*
  ***************************************************************************
  ** Members **
  *************
  **
  */
  
  /**
  ** The field that has the clipboard content.
  */
  private static final int USER_FIELD =   1;
  private static final int BUFFER_NUM_FIELD = 2;
  private static final int CONTENT_FIELD =  3;
  
  /**
  ** The value of the first field, used to uniquely identify
  ** the tuple.
  */
  // I don't think this should be private (tjl 3/23/98)
  // private 
  public static final String CLIPBOARD    =    "TClipboard";
  
  /*
  ***************************************************************************
  ** TClipboardTuple **
  ********************
  */
  /**
  ** Make a formal TClipboardTuple to match with a tuple with any user, 
  ** any buffer, any content string.
  ***************************************************************************
  */
  public TClipboardTuple( ) throws TupleSpaceException {
    super( CLIPBOARD, 
           Field.makeField( "java.lang.String" ),
	   Field.makeField( "java.lang.Integer" ),
           Field.makeField( "java.lang.String" ) );
  } // TClipboardTuple
  
  /*
  ***************************************************************************
  ** TClipboardTuple **
  ********************
  */
  /**
  ** Make a formal TClipboardTuple to match with a tuple with any string
  ** in any buffer for a given user.
  ** @param user_ - the user we're looking for.
  ***************************************************************************
  */
  public TClipboardTuple( String user_ ) throws TupleSpaceException {
    super( CLIPBOARD, 
	user_, 
	Field.makeField( "java.lang.Integer" ),
	Field.makeField( "java.lang.String" ) );
  } // TClipboardTuple
  
  /*
  ***************************************************************************
  ** TClipboardTuple **
  ********************
  */
  /**
  ** Make a formal TClipboardTuple to match with a tuple with any string
  ** for a given user.
  ** @param user_ - the user we're looking for.
  ** @param bufferNum_ - the buffer we're looking for.
  ***************************************************************************
  */
  public TClipboardTuple( String user_, int bufferNum_ ) throws TupleSpaceException {
    super( CLIPBOARD, 
	    user_, 
	    new Integer( bufferNum_ ),
	    Field.makeField( "java.lang.String" ) );
  } // TClipboardTuple
  
  /*
  ***************************************************************************
  ** TClipboardTuple **
  ********************
  */
  /**
  ** Make a TClipboardTuple with passed string.
  ** @param user_ - The user who owns these tuples
  ** @param bufferNum_ - The buffer that this tuple represents.
  ** @param data_ - The data we're adding (or looking for).
  ***************************************************************************
  */
  public TClipboardTuple( String  user_, int bufferNum_, String data_ ) throws TupleSpaceException {
    super( CLIPBOARD, 
	user_, 
	new Integer( bufferNum_ ),
	data_ );   
  } // TClipboardTuple
  
  /*
  ***************************************************************************
  ** getUser **
  *************
  */
  /**
  ** Return the USER NAME.
  ** @return Return the USER NAME.
  ***************************************************************************
  */
  String getUser() throws TupleSpaceException {
    String x = (String)getField( USER_FIELD ).getValue();
    return x;
  } // getUser

  /*
  ***************************************************************************
  ** getBufferNum **
  ******************
  */
  /**
  ** Return the BUFFER NUMBER that this tuple represents for the user.
  ** @return Return the BUFFER NUMBER
  ***************************************************************************
  */
  int getBufferNum() throws TupleSpaceException {
    Integer x = (Integer)getField( BUFFER_NUM_FIELD ).getValue();
    return x.intValue();
  } // getBufferNum

  /*
  ***************************************************************************
  ** getContent **
  ****************
  */
  /**
  ** Return the data string.
  ** @return Return the data string.
  ***************************************************************************
  */
  String getContent() throws TupleSpaceException {
    String x = (String)getField( CONTENT_FIELD ).getValue();
    return x;
  } // getContent
} // TClipboardTuple

/*
$History: TClipboardTuple.java $
 * 
 * *****************  Version 5  *****************
 * User: Jthomas      Date: 1/29/99    Time: 9:59a
 * Updated in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/copypaste
 * new Field methods
 * Debug stuff
 * 
 * *****************  Version 4  *****************
 * User: Thomas       Date: 8/28/98    Time: 7:24p
 * Updated in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/copypaste
 * uh
 * 
 * *****************  Version 3  *****************
 * User: Toby         Date: 3/23/98    Time: 8:45a
 * Updated in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/copypaste
 * 
 * *****************  Version 2  *****************
 * User: Toby         Date: 3/23/98    Time: 8:44a
 * Updated in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/copypaste
 * Had to export a few things (make them public) so that other classes
 * could share in the joy of copypaste
 * 
 * *****************  Version 1  *****************
 * User: Jthomas      Date: 1/27/98    Time: 5:51p
 * Created in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/copypaste
 * 
 * *****************  Version 1  *****************
 * User: Toby         Date: 1/23/98    Time: 9:41a
 * Created in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/copypaste
 * 
 * *****************  Version 10  *****************
 * User: Jthomas      Date: 12/02/97   Time: 12:16a
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces/examples/copypaste
 * Updated to match BlueClipboard.java
 * 
 * *****************  Version 4  *****************
 * User: Toby         Date: 10/02/97   Time: 6:37p
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces/examples/copypaste
 * Changed most of these (copypaste thru Rhonda) to the new lower case com
 * model.  Also cleaned up a few deprecated APIs and got some old stuff
 * working (or at least commented out).  Will be back for the remaining
 * examples sometime later.
 * 
 * *****************  Version 2  *****************
 * User: Smclaugh     Date: 9/20/97    Time: 6:57p
 * Updated in $/GCS/Development/Java/COM/ibm/almaden/tuplespace/examples/copypaste
 * Added a constructor
 * 
 * *****************  Version 1  *****************
 * User: Smclaugh     Date: 9/17/97    Time: 10:36p
 * Created in $/GCS/Development/Java/COM/ibm/almaden/tuplespace/examples/copypaste
 * Version 1.2 of the GCSClipboard.
*/
/* $Log: TClipboardTuple.java,v $
/* Revision 2.1  1999/11/05 22:22:38  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:38  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



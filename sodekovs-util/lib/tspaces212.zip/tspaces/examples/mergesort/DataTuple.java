// DataTuple.java

package com.ibm.tspaces.examples.mergesort;

import  java.util.*;
import	com.ibm.tspaces.*;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

/**
** This class represents a set of ordered integers.
**
** @see Tuple
** @see Field
** @see TupleSpace
** @version $Revision: 2.1.2.1 $ $Date: 2000/08/30 12:54:18 $
** @author Daniel Ford
*/

public class DataTuple extends SubclassableTuple {

  /*
  ***************************************************************************
  ** ** Members **
  ** *************
  **
  */
  
  /**
  ** The field that has the integers.
  */
  private static final int INTEGERS_FIELD =    1;
  
  /**
  ** The value of the first field, used to uniquely identify
  ** the tuple.
  */
  private static final String DATA         =    "Data";
  
  /*
  ***************************************************************************
  ** ** DataTuple **
  ** ***************
  */
  /**
  ** Make a formal DataTuple to match with a tuple with any set of numbers.
  ***************************************************************************
  */
  DataTuple() throws TupleSpaceException {
    super( DATA, new Field(Vector.class ) );
		
  } // DataTuple
  
  /*
  ***************************************************************************
  ** ** DataTuple **
  ** ***************
  */
  /**
  ** Make with the Vector of integers.
  ** @param integers an ordered set of integers, smallest first.
  ***************************************************************************
  */
  DataTuple( Vector integers) throws TupleSpaceException {
    super( DATA, integers );		
  } // DataTuple
	
  /*
  ***************************************************************************
  ** ** getIntegers **
  ** *****************
  */
  /**
  ** Return the ordered set of integers.
  ** @return the ordered set of integers.
  ***************************************************************************
  */
  Vector getIntegers() throws TupleSpaceException {
  	return (Vector)getField( INTEGERS_FIELD ).getValue();
  } // getIntegers


} // DataTuple
/* $Log: DataTuple.java,v $
/* Revision 2.1.2.1  2000/08/30 12:54:18  jthomas
/* minor improvements to testcase
/*
/* Revision 2.2  2000/08/07 13:51:25  jthomas
/* changed to help find locking bug
/*
/* Revision 2.1  1999/11/05 22:22:38  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:39  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



// VectorWithEquals.java

package com.ibm.tspaces.examples.mergesort;

// OEM Certified:  Toby, Sept 14, 1998
/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

import java.util.*;
import java.io.Serializable;
import com.ibm.tspaces.Debug;
/**
*************************************************************************
** This is the same as the Vector utility class except that equals is
** performed element be element rather than using pointers. So two of
** these vectors are equal if they have the same # of elements, and
** each element in order is equal.
**
** @version $Revision: 1.1.2.1 $ $Date: 2000/08/30 17:17:41 $
** @author Pete Wyckoff
*************************************************************************
*/
public class VectorWithEquals extends Vector  {
	
  public VectorWithEquals() { 
    super();
  }
  
  public VectorWithEquals(int initialCapacity) {
    super(initialCapacity);
  }

  public VectorWithEquals(int initialCapacity, int capacityIncrement) {
    super(initialCapacity, capacityIncrement);
  }

  /**************************************************************************
  ** Equals **
  ***********/
  /**
  ** Do equals  on the element, rather than the pointer
  ***************************************************************************
  */
  public boolean equals(Object other_) {
    if(!( other_ instanceof Vector))
	    return false;

    if(this.size() != ((Vector)other_).size())
	    return false;
    Enumeration mine, others;
    for( mine = this.elements(),
         others = ((Vector)other_).elements();
	 mine.hasMoreElements() ; )
    {
      final Object oneOfMine = mine.nextElement();
      final Object oneOfHis  = others.nextElement();
      if(! oneOfMine.equals(oneOfHis))
	      return false;
    } // end for 
    return true;
  } // equals
  
  
  public String toString()  {
    
    StringBuffer sb = new StringBuffer();
    try  {
      
      int sz = this.size();
      sb.append("Vector size="+sz+"[");
      Enumeration enum = this.elements(); 
      int i = 0;
      boolean middle = false;
      for (;enum.hasMoreElements();i++)  {
        Object element = enum.nextElement();
        if ( i < 5 )    {    
          sb.append(element+" ");
        } else if (i >  sz - 4)  {
          sb.append(element + " ");
        } else if (!middle )  {
          sb.append("... ");
          middle = true;
        }
      } // for
      
      sb.append("] ");
      
    } catch (Exception e)  {
      Debug.out(e);
    }
    return sb.toString();
  }
  
  /*
  ** dump is like toString but it displays the entire vector
  */
  public String dump()  {
    
    StringBuffer sb = new StringBuffer();
    try  {
      
      int sz = this.size();
      sb.append("Vector size="+sz+"[");
      Enumeration enum = this.elements(); 
      int i = 0;
      boolean first = true;
      for (;enum.hasMoreElements();i++)  {
        Object element = enum.nextElement();
        if (! first)
          sb.append(",");
        else 
          first = false;  
        sb.append(element);
        
        
      } // for
      
      sb.append("] ");
      
    } catch (Exception e)  {
      Debug.out(e);
    }
    return sb.toString();
  }
} // class VectorWithEquals

/*
$History: VectorWithEquals.java $
 * 
 * *****************  Version 3  *****************
 * User: Toby         Date: 9/14/98    Time: 5:54p
 * Updated in $/GCS/Development/TSpaces/Java/com/ibm/tspaces
 * OEM Check -- cleaned up files for public consumption
 * 
 * *****************  Version 2  *****************
 * User: Thomas       Date: 7/29/98    Time: 11:10a
 * Updated in $/GCS/Development/TSpaces/Java/com/ibm/tspaces
 * No changes were made
 * 
 * *****************  Version 1  *****************
 * User: Toby         Date: 1/23/98    Time: 12:33a
 * Created in $/GCS/Development/TSpaces/Java/com/ibm/tspaces
 * Initial checkin for T Spaces
 * 
 * *****************  Version 5  *****************
 * User: Wyckoff      Date: 1/09/98    Time: 1:05p
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces
 * 
 * 
 * *****************  Version 4  *****************
 * User: Toby         Date: 10/02/97   Time: 7:09p
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces
 * Big change.  New structure (from ibm.almaden.tuplespace to
 * ibm.bluespaces) and new convention for the package name (was large COM
 * and is now small com).   Fixed up a few deprecated methods.
 * 
 * *****************  Version 2  *****************
 * User: Eichstam     Date: 8/31/97    Time: 1:06p
 * Updated in $/GCS/Development/Java/COM/ibm/almaden/tuplespace
 * fixed history tag
*/

/* $Log: VectorWithEquals.java,v $
/* Revision 1.1.2.1  2000/08/30 17:17:41  jthomas
/* no message
/*
/* Revision 2.1  1999/11/05 22:22:37  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:51  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:32  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



// CountTuple.java

package com.ibm.tspaces.examples.mergesort;

import  java.util.*;
import	com.ibm.tspaces.*;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

/**
** This class a single integer that is the count of the number
** of integers to be sorted.
**
** @see Tuple
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:38 $
** @author Daniel Ford
*/

public class CountTuple extends SubclassableTuple {

  /*
  ***************************************************************************
  ** ** Members **
  ** *************
  **
  */
  
  /**
  ** The field that has the integers.
  */
  private static final int COUNT_FIELD =    1;
  
  /**
  ** The value of the first field, used to uniquely identify
  ** the tuple.
  */
  private static final String COUNT    =    "Count";
  
  /*
  ***************************************************************************
  ** ** CountTuple **
  ** ***************
  */
  /**
  ** Make a formal CountTuple to match with a tuple with any set of numbers.
  ***************************************************************************
  */
  CountTuple() throws TupleSpaceException {
    super( COUNT, Field.makeField( "java.lang.Integer" ) );
  } // CountTuple

  /*
  ***************************************************************************
  ** ** CountTuple **
  ** ***************
  */
  /**
  ** Make a CountTuple with passed integer
  ** @param count the integer
  ***************************************************************************
  */
  CountTuple( Integer  count ) throws TupleSpaceException {
    super( COUNT, count );		
  } // CountTuple
	
  /*
  ***************************************************************************
  ** ** CountTuple **
  ** ***************
  */
  /**
  ** Make a CountTuple with passed integer
  ** @param count the integer
  ***************************************************************************
  */
  CountTuple( int  count ) throws TupleSpaceException {
    super( COUNT, new Integer( count ) );		
  } // CountTuple

  /*
  ***************************************************************************
  ** ** getCount **
  ** *****************
  */
  /**
  ** Return the integer.
  ** @return Return the integer.
  ***************************************************************************
  */
  int getCount() throws TupleSpaceException {
    Integer x = (Integer)getField( COUNT_FIELD ).getValue();
    return x.intValue();
  } // getCount


} // CountTuple
/* $Log: CountTuple.java,v $
/* Revision 2.1  1999/11/05 22:22:38  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:39  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



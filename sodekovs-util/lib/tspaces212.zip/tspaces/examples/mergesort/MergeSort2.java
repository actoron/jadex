// MergeSort2.java

package com.ibm.tspaces.examples.mergesort;

import	java.util.*;
import	com.ibm.tspaces.*;
import  com.ibm.tspaces.services.utility.Worker;
import  com.ibm.tspaces.services.utility.Eval;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

/**
** This class implements a merge sort using TupleSpace.  It is an
** example of how to use the com.ibm.tspaces package.
** It generates a number of random integers and then uses TupleSpace
** as a communication medium to coordinate the activities of a
** number of threads that perform the actual sorting/merging.
** This version of MergeSort2 makes use of the Merger class 
** that implements the Eval interface so that Worker threads
** on other systems can do the work. 
** 
** @see Tuple
** @see Field
** @see TupleSpace
** @version $Revision: 2.1.2.1 $ $Date: 2000/10/18 12:44:08 $
** @author Daniel Ford
*/

public class MergeSort2 extends Thread {

  /*
  ***************************************************************************
  ** ** Members **
  ** *************
  **
  */

  /**
  ** The default number of integers to be randomly generated and then sorted.
  */
  private static final int	DEFAULTNUMINTSTOSORT = 10;

  /**
  ** The default maxium value of the integers to be sorted.
  */
  private static final int	DEFAULTMAXINTVALUE = 1000;

  /**
  ** The default number of threads to be started that perform the actual sorting.
  */
  private static final	int	DEFAULTNUMSORTTHREADS	= 2;

  /**
  ** The default name of the tuple space to use to do the sorting in.
  */
  public static final String	DEFAULTSPACENAME	= "mergesort";

  /**
  ** The default name of the server hosting the tuple space for the sort.
  */
  public static final String	DEFAULTSERVERNAME	= "localhost";
  
  
  /**
  ** The number of integers to sort.
  */
  private	int		numberOfInts							=	0;

  /**
  ** The maximum value of any integer to be sorted
  */
  private	int		maxIntValue								=	0;

  /**
  ** The number of threads to be used to sort the integers	
  */
  private	int		numberOfTasks						=	0;
  private SortThread[] _st                 = null;
  /**
  ** The name of the TupleSpace to be used to do the sorting
  */
  private	String	spaceName								=	"";

  /**
  ** The name of the server that hosts the tuple space	
  */
  private	String	serverName								=	"";

  


  /*
  ***************************************************************************
  ** ** MergeSort2 **
  ** ***************
  */
  /**
  ** Sort a set of randomly generated integers.
  **
  ** @param numberOfInts the number of random integers to generate and then
  **		sort.
  ** @param maxIntValue the maximum value of one of the randomly generated
  **		integers to be sorted.
  ** @param tasks the number of threads to be used to sort the
  **		the integers.  Each one will make its own accesses to the 
  **	    TupleSpace.
  ** @param spaceName the name of the space to be used to do the sorting.
  ** @param serverName the name of the server that is managing the space.
  ***************************************************************************
  */
  public MergeSort2( int numberOfInts, String serverName, String spaceName,int tasks ) {

      this.numberOfInts	= numberOfInts;
      this.serverName	= serverName;
      
      this.spaceName	= spaceName;
      this.numberOfTasks = tasks;
	    try {
        // Get the tuple space
        TupleSpace  ts  =  new TupleSpace( spaceName, serverName );
	      
	    }  catch( TupleSpaceException tse ) {
      Debug.out( tse );
      
      } // catch

      
  } // MergeSort2


  /*
  ***************************************************************************
  ** ** addVectorsToSpace **
  ** ***********************
  */
  /**
  ** Create a set of N tuples each having a single integer
  **
  ** @param ts the tuple space to be used to hold the values to be sorted
  ** @param numberOfInts the number of integers to generate and then
  **			sort.
  
  ** @exception TupleSpaceException if there are problems using the 
  **			TupleSpace.
  ***************************************************************************
  */
  private void addVectorsToSpace(
    TupleSpace ts,     int numberOfInts)
    
      throws TupleSpaceException
  {

    int	count		=	0; // Number of ints made so far
    Tuple multi = new Tuple();
    while ( count < numberOfInts ) {
      
      int vSize = 1; // for now DAF

      
      count += vSize;

      // Put the vector into the tuplespace.
      
      VectorWithEquals v = new VectorWithEquals();
      v.addElement( new Integer( count-1 ) );
      //Debug.out( "Adding " + (count-1) + ": " + v.toString() );
      //ts.write( new DataTuple( v ) );
      multi.add(new Field(new DataTuple(v)));

    } // while
    ts.multiWrite(multi);
    Debug.out("Wrote "+count+" tuples");
  } // addVectorsToSpace


  

  /*
  ***************************************************************************
  ** ** startWorkerThreads **
  ** **********************
  */
  /**
  ** This will write N tuples containing the Merger object to the Worker Tuplespace 
  ** 
  ** Worker clients that are watching the Worker space will take one of the 
  ** tuples and invoke the run() method on the Merger object.  
  **
  ** @param host   Host name where the Worker space resides.
  ** @param numberOfTasks  The max number of worker tasks we will setup
  **
  ***************************************************************************
  */
  private void startWorkerTasks( String host, int numberOfTasks ) {
							  
    try {
      TupleSpace work = new TupleSpace(Worker.WORKER_TSNAME,host);
      // create the specified number of tuples containing Merger Objects      
    	for ( int i = 0; i < numberOfTasks; i++ ) {
        Merger merger = new Merger("mergesort", host);
    		Tuple workTuple = new Tuple(Worker.WORKER_KEY,"Merger","sm"+i, merger);
        work.write(workTuple);
      } // for
    }  catch( TupleSpaceException tse ) {
      Debug.out( tse );
      
    } // catch
    
  } // startWorkerThreads
	


  /*
  ***************************************************************************
  ** ** removeWorkerThreads **
  ** **********************
  */
  /**
  ** This will take any remaining worker threads out of the 
  ** Worker space.  Some may have been unused and 
  ** we don't want them to get picked up by the terminating
  ** worker threads. 
  **
  ** @param host   Host name where the Worker space resides.
  ** @param numberOfTasks  The max number of worker tasks we will setup
  **
  ***************************************************************************
  */
  private void removeWorkerTasks( String host ) {
                
    try {
      TupleSpace work = new TupleSpace(Worker.WORKER_TSNAME,Worker.WORKER_TSHOST);
      Tuple template = new Tuple(Worker.WORKER_KEY,"Merger",
                new Field(String.class),new Field(Eval.class));
    	Tuple result = work.consumingScan(template);
      Debug.out("removeWorkerThreads: "+result);
    }  catch( TupleSpaceException tse ) {
      Debug.out( tse );
      
    } // catch
    
  } // removeWorkerTasks
  
  /*
  ***************************************************************************
  ** ** run **
  ** *********
  */
  /**
  ** Starting point of execution for thread.
  ***************************************************************************
  */
  public void run() {

    try {
      // Get the tuple space
      TupleSpace	ts	=	new TupleSpace( spaceName, serverName );
	    
      if (Debug.isDebugOn()) 
	 	    ts.setDebug(true);
      
      // Add Vectors of random integers to the tuple space.  The number of 
      // integers in each Vector is random, but the total number will equal
      // numberOfInts.
      ts.deleteAll();  
      
      addVectorsToSpace( ts, numberOfInts );

      // Add the total number of integers to the space.
      ts.write( new CountTuple( numberOfInts ));
    	
      // Write the Merger objects that will do the actual sorting.
    	// to the Worker space
      startWorkerTasks( serverName, numberOfTasks );
      

      // Now try to get the answer.
      DoneTuple result = (DoneTuple)ts.waitToRead( new DoneTuple() );
      
      // Print out the answer.
      Debug.out( "\nThe sorted integers are:" );
      Debug.out( result.getIntegers().toString() );
      removeWorkerTasks(serverName);
      
     
      ts.deleteAll();
      ts.cleanup();
    } // try
    catch( TupleSpaceException tse ) {
      Debug.out( "Caught a TupleSpace Exception: \"" +
			 tse.getMessage() +   "\"" );
      tse.printStackTrace( System.out );
    } // catch

  } // run

  /*
  ***************************************************************************
  ** ** puase **
  ** ***********
  */ 
  /**
  ** Suspend the thread for the indicated number of seconds.  This is useful
  ** for giving a user enough time to read a message displayed on the 
  ** console before the server goes down
  **
  ** @param seconds the number of seconds to pause
  **************************************************************************
  */
  private static void pause( int seconds ) {
    try {
      Thread.sleep( seconds * 1000 );
    } // try
    catch( InterruptedException ie ) {}

  } // pause

  /*
  ***************************************************************************
  ** ** Main **
  ** **********
  */
  /**
  ** The starting point of execution for the merge sort.
  ***************************************************************************
  */
  public static void main( String argv[] ) {

    try {
      int 	numInts		=	DEFAULTNUMINTSTOSORT;	  	
      String	tsServerName	=	DEFAULTSERVERNAME;
      String  tsSpaceName = "mergesort";
      
      // standard processing of operands
      if ( argv.length == 0) 
        System.out.println("Usage:  MergeSort2 [-D] [-h tsHost] count");
      for (int i=0; i< argv.length; i++) {
        if (argv[i].equals("-D") )
          Debug.setDebugOn(true);
        else if (argv[i].equals("-h")) {
          tsServerName = argv[++i];        
        } else         
          // if numeric than count
          try {
            numInts = Integer.parseInt( argv[i] );        
  
          } // try
          catch( NumberFormatException nfe ) {
            // Must be a host name
            tsServerName = argv[i];          
    
          } // catch
      }
    
    

      
	  
	   long starttime = System.currentTimeMillis();
	   long totaltime;
      
      
      starttime = System.currentTimeMillis();

      MergeSort2	ms =	new MergeSort2(  numInts, tsServerName, tsSpaceName, 4);
      ms.start();
      ms.join();	// wait until it's done
	    totaltime = System.currentTimeMillis() - starttime;
      System.out.println(numInts + " sorted.  Time : " + totaltime);
      // Get the tuple space
      TupleSpace  ts  =  new TupleSpace( tsSpaceName, tsServerName );
      ts.cleanup();
      Debug.out( "MergeSort2 ending" );
    } // try
    catch( Exception e ) {
      Debug.out( "Got Exception: \"" + e.getClass().getName() + "\" " + e.getMessage() );

    } // catch
    catch( Error err ) {
      Debug.out( "Got Error: \"" + err.getClass().getName() + "\" " + err.getMessage() );

    } // catch

    
    System.exit(0);
  
  } // main

} // MergeSort2
/* $Log: MergeSort2.java,v $
/* Revision 2.1.2.1  2000/10/18 12:44:08  jthomas
/* no message
/*
/* Revision 2.1  1999/11/05 22:22:39  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.3  1999/09/13 05:10:37  jthomas
 * because Worker is in new package
 *
 * Revision 1.2  1999/06/17 05:39:39  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */


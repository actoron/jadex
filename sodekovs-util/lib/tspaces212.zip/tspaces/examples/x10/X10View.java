// X10View.java

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

package	com.ibm.tspaces.examples.x10;

import java.awt.event.*;
import java.awt.*;
import java.applet.*;
import java.net.*;
import java.util.Vector;
import java.lang.reflect.*;
import com.ibm.tspaces.*;
/**
** This class will view the status of the various X10 devices 
** that are stored in TupleSpace X10
** 
** All of the Tuplespace related code is X10ViewPanel.java
** 
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:40 $
** @author John Thomas

*/
public class X10View extends Applet{

	private static X10View x10View;
 	private static boolean application = false;
    // X10ViewPanel will use these if set    
    protected static String host=null;
    
    
    // This will be set true when start() called and 
    // set to false when stop() is called;
    protected static boolean PaintOK = true;
    
    protected static final int WIDTH = 240;
    protected static final int HEIGHT = 300;
    //private X10ViewPanel wp = null;
    private Panel wp = null;
	public Frame 	appFrame;
	private boolean applet = false;
	
	private boolean Error = false;
	private String ErrorMsg = "";
	
public 
X10View() {
		
}
    /*
    ***************************************************************************
    ** ** init **
    ** **********
    */
    /**
    ** Initialization: 
    ** This could be entered automatically when running as an applet 
    ** or by being called from main() is being run from an 
    ** application.
    **
    **
    *************************************************************************** 
    */
    public void init() {
    	Debug.out("init()");
    	if (application) {                 // Running as an application
    	    
    		appFrame = new Frame("TSpaces X10View");
    		appFrame.add("Center", x10View);
        appFrame.setSize(WIDTH,HEIGHT);   
    	} else  {    // Running as an applet
    	
    		applet = true;
    		x10View = this;  
    		// We will assume that Tuplespace is on same host as applet codebase
    		URL url = getCodeBase();
    		String urlhost = url.getHost();
    		
    		if (urlhost.length() != 0) 
    		  host = urlhost;
    	  String strport  = getParameter("port");
    	  if (strport != null) 
    	      host=host+":"+strport;
			
    		Debug.out("Host="+host);    		
    
    	}
    	
    	x10View.setLayout(new BorderLayout());
    	// --------------------------------------------------------------
    	// Now we want to create the instance of X10ViewPanel
    	// but it has JDK 1.1 eventmodel code that may not be supported 
    	// by the browser.  So we will cause it to be loaded and invoked 
    	// under a try/catch block that will handle any errors.
    	// 
    	// Note that we have had to be careful to remove any reference 
    	// to X10ViewPanel or X10ViewControls from this code so that
    	// they will not be loaded earlier.
    	if ( ! Error ) 
	    	try {
	    		Class wpclass = Class.forName("com.ibm.tspaces.examples.x10.X10ViewPanel");
	        	if ( wpclass != null )
	        		x10View.wp = (Panel)wpclass.newInstance();
	        	if ( wpclass == null || x10View.wp == null) 
	        		throw new Exception("X10View Creation Error");
	        	// We have the Panel object, so add it to the layout
	        	x10View.add("Center", wp);
	            // now we need to call wp.init(this) 
	        	Class myClass[] = { X10View.class };
	        	Method initMethod = wpclass.getMethod("init",myClass);   
	        	Object param[] = { this };
	        	initMethod.invoke(wp, param);
	        } catch (Exception e) {
	        	if (applet) 
	        		if ( e.getMessage().endsWith("Listener"))
	        			ErrorMsg = "Your browser does not fully support JDK 1.1; Class="+e.getMessage();
	        		else
	        			ErrorMsg = "Browser error while loading class: " +	e.getMessage();
	        	else
	        		ErrorMsg = "Exception while loading class X10ViewPanel: " +	e.getMessage();
 
	        	System.out.println(ErrorMsg);
	        	if (applet) 
	        		this.showStatus(ErrorMsg);
	        	Debug.out(e);
	        	Error = true;
	        	
	        }  catch (Error err) {
	        
	        	ErrorMsg = 
	        	  "Error while loading class X10ViewPanel: " +	
	        	  err.getMessage() + "\n" + err.toString();
 
	        	System.out.println(ErrorMsg);
	        	if (applet) 
	        		this.showStatus(ErrorMsg);
	        	err.printStackTrace();
	        	Error = true;
	        	
	        }

        
        if (Error) {
        	Label err = new Label(ErrorMsg);
        	x10View.add("South",err);
        }				
        
   
		if ( ! applet) 
			appFrame.show();
		else {
			
    	}	
             

    } // init
	
	/*
    ***************************************************************************
    ** ** run **
    ** **********
    */
    /**
    ** run: Is entered as as a result of a start thread 
    ** It is not currently being used.
    **
    *************************************************************************** 
    */
   

	
	public void
	run() {
		Debug.out("run()");
		while (true) 
			try {
				Thread.currentThread().sleep(5000);
		    } catch (InterruptedException ie) {}
	}
	
	/*
    ***************************************************************************
    ** ** start **
    ** **********
    */
    /**
    ** start() is called when it is time for the applet to start doing stuff.
    **
    ** This could be called multiple times as the applet is stopped and started. 
    **
    **
    *************************************************************************** 
    */
    public void 
    start()  {
		Debug.out("start()");
		PaintOK = true;
	}
	
	/*
    ***************************************************************************
    ** ** stop **
    ** **********
    */
    /**
    ** stop() is called when the applet is no longer visible so we no longer need to 
    ** keep painting the screen, but we should still listen for events.
    **
    ** This could be called multiple times as the applet is stopped and started. 
    **
    **
    *************************************************************************** 
    */
    public void 
    stop()  {
		Debug.out("stop()");
		PaintOK = false;
	}
	
	/*
    ***************************************************************************
    ** ** destroy **
    ** **********
    */
    /**
    ** destroy() is called when the applet is going to be permanently stoped
    **
    **
    *************************************************************************** 
    */
    public void 
    destroy()  {
		Debug.out("destroy()");
		wp.removeAll();   // cause X10ViewPanel to get control
	}

	
    /*
    ***************************************************************************
    ** ** main **
    ** **********
    */
    /**
    ** Run the x10View as an application.
    **
    ** @param args - command line arguments
    *************************************************************************** 
    */
  public static void main(String args[]) {
    application = true;
    Debug.setDebugOn(false);
    for (int i=0; i< args.length; i++) {
      if(args[i].equals("-D")) {
        Debug.setDebugOn(false);
      } else if (args[i].equals("-h")) {
        host = args[++i];
      }
    }
  
    x10View = new X10View();
    x10View.init();          
    x10View.start();        
  } // main
} // X10View

/*
$History: X10View.java $
 * 
 * *****************  Version 1  *****************
 * User: Jthomas      Date: 2/03/99    Time: 10:58a
 * Created in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/x10
 
*/
/* $Log: X10View.java,v $
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:54  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.3  1999/11/03 16:09:13  jthomas
 * Minor cleanup while testing with Jeode
 *
 * Revision 1.2  1999/06/17 05:39:50  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



// X10MonitorException.java

package com.ibm.tspaces.examples.x10;

// OEM Certified:  Toby, Sept 14, 1998
/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997, 1998  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
*/

import	java.text.*;
import  java.util.*;

/**
**************************************************************************
**  A X10MonitorException represents an exception to the normal processing
**  of a X10Monitor.
**
** @see X10Monitor
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:40 $
** @author John Thomas
**************************************************************************
*/

public class X10MonitorException extends Exception {
  /*
  ** This is a list of Locales which are supported in the current version.
  */
  private static final Locale supportedLocales[] = {
    Locale.US,
    
  };

  /*
  ** This is the locale we are currently running with.
  */
  private static Locale currentLocale = supportedLocales[0];

  /*
  ** The name of the ResourceBundle that contains the localized messages
  ** for this class/package.  
  */
  private	static final String	RESOURCE_BUNDLE_NAME = 
		"com.ibm.tspaces.X10MonitorERB";

  /*
  ** This variable holds the ResourceBundle for this class if it has been 
  ** loaded once.  This avoids loading it more than once.   
  */
  private	static ResourceBundle resourceBundle	=	null;


  /**
  ** Create a X10Monitor exception and record a reason for the
  ** exception.
  **
  ** @param msg The reason for the X10Monitor exception
  */
  public X10MonitorException( String msg ) {
    super( msg );
  } // X10MonitorException

  /*
  *************************************************************************
  ** X10MonitorException **
  *************************
  */
  /**
  ** Create a X10Monitor exception and record a reason for the
  ** exception.
  **
  ** @param messageString A localized message pattern for use by the
  **			class MessageFormat
  ** @param messageParameters The array of parameters to be substituted
  **			into the message string during formating
  *************************************************************************
  */
  public X10MonitorException( String messageKey, Object[] messageParameters ) {
    super( MessageFormat.format( getBundle().getString( messageKey ), 
					  removeNulls(messageParameters )));
  } // X10MonitorException

  /*
  *************************************************************************
  ** X10MonitorException **
  *************************
  */
  /**
  ** Create a X10Monitor exception and record a reason for the
  ** exception.
  **
  ** @param messageString A localized message pattern for use by the
  **			class MessageFormat
  ** @param p1 a paramater to be substituted into the format string
  *************************************************************************
  */
  public X10MonitorException( String messageKey, Object p1 ) {
    this(messageKey, new Object[] {p1 });
  } // X10MonitorException


  /*
  *************************************************************************
  ** X10MonitorException **
  *************************
  */
  /**
  ** Create a X10Monitor exception and record a reason for the
  ** exception.
  **
  ** @param messageString A localized message pattern for use by the
  **			class MessageFormat
  ** @param p1 a paramater to be substituted into the format string
  ** @param p2 a paramater to be substituted into the format string
  *************************************************************************
  */
  public X10MonitorException( String messageKey, Object p1, Object p2 ) {
    this(messageKey, new Object[] { p1,p2});
  } // X10MonitorException

  /*
  *************************************************************************
  ** X10MonitorException **
  *************************
  */
  /**
  ** Create a X10Monitor exception and record a reason for the
  ** exception.
  **
  ** @param messageString A localized message pattern for use by the
  **			class MessageFormat
  ** @param p1 a paramater to be substituted into the format string
  ** @param p2 a paramater to be substituted into the format string
  ** @param p3 a paramater to be substituted into the format string
  *************************************************************************
  */
  public X10MonitorException( String messageKey, Object p1, Object p2,
  			      Object p3 )
  {
    this(messageKey,new Object[] {p1,p2,p3 });
  } // X10MonitorException

  /*
  *************************************************************************
  ** X10MonitorException **
  *************************
  */
  /**
  ** Create a X10Monitor exception and record a reason for the
  ** exception.
  **
  ** @param messageString A localized message pattern for use by the
  **			class MessageFormat
  ** @param p1 a paramater to be substituted into the format string
  ** @param p2 a paramater to be substituted into the format string
  ** @param p3 a paramater to be substituted into the format string
  ** @param p4 a paramater to be substituted into the format string
  *************************************************************************
  */
  public X10MonitorException( String messageKey, Object p1, Object p2,
			       Object p3, Object p4 )
  {
    this(messageKey, new Object[] {p1,p2,p3,p4});
  } // X10MonitorException

  /*
  *************************************************************************
  ** X10MonitorException **
  *************************
  */
  /**
  ** Create a X10Monitor exception and record a reason for the
  ** exception.
  **
  ** @param messageString A localized message pattern for use by the
  **		class MessageFormat
  ** @param p1 a paramater to be substituted into the format string
  ** @param p2 a paramater to be substituted into the format string
  ** @param p3 a paramater to be substituted into the format string
  ** @param p4 a paramater to be substituted into the format string
  ** @param p5 a paramater to be substituted into the format string
  *************************************************************************
  */
  public X10MonitorException( String messageKey, Object p1, Object p2,
			      Object p3,  Object p4, Object p5 )
  {
    this(messageKey,	new Object[] {p1,p2,p3,p4,p5});
  } // X10MonitorException

  

  /*
  **************************************************************************
  ** removeNulls **
  *****************
  */
  /**
  ** remove the nulls from the params because they will cause a problem
  ** when formatting.
  **
  ** @param params the original params
  ** @return the params with String "null" replaced for nulls
  **************************************************************************
  */
  static protected Object[] removeNulls(Object [] params) {
    if(params == null)
      return null;

    for(int i = 0 ; i < params.length ; i++) 
      params[i] = params[i] == null ? "null" : params[i];
    return params;
  }	
  
  
  /*
  ***************************************************************************
  ** getBundle ** 
  ***************
  */
  /**
  ** Return the appropriate ResourceBundle instance.  The 
  ** ResourceBundle is used to get localization strings for messages.
  **
  ** @return an instance of ResourceBundle
  ***************************************************************************
  */
  protected static ResourceBundle getBundle() {
    if(currentLocale == null)
      currentLocale = supportedLocales[0]; // default to en_US here
    if ( resourceBundle == null )
      resourceBundle = ResourceBundle.getBundle(RESOURCE_BUNDLE_NAME, currentLocale );

    return resourceBundle;

  } // getBundle


} // X10MonitorException

/*
$History: X10MonitorException.java $
 * 
 * *****************  Version 1  *****************
 * User: Jthomas      Date: 2/03/99    Time: 10:58a
 * Created in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/x10
 
 */
/* $Log: X10MonitorException.java,v $
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:50  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



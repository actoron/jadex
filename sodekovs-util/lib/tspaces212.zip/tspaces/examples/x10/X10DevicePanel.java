// X10DevicePanel.java

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

package	com.ibm.tspaces.examples.x10;

import java.awt.event.*;
import java.awt.*;
import java.applet.*;
import java.util.*;
import com.ibm.tspaces.*;

/**
** The panel that defines one of the X10Devies .
** 
**  
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:40 $
** @author John Thomas
*/
public class X10DevicePanel 
	extends Panel   
	implements Callback 	{

  protected static Color BACKGROUND_COLOR = Color.yellow;
 
  private X10ViewPanel x10view = null;
	
	/**
	** This holds a reference to the current TupleSpace.
	*/
	protected TupleSpace _ts = null;
	
	/**
	** This is the address of the X10 Device ( i.e. "A1")
	*/
  protected String   _address = null;
	protected String   _name = null;
	protected Label    _statusLabel = null;
/*
***************************************************************************
** ** X10DevicePanel **
** *********************
*/
/**
** The constructor 
**
*************************************************************************** 
*/
public X10DevicePanel(TupleSpace ts, String address,String name) {
  super();
	setLayout(new GridLayout(0,1,0,0));
	_ts = ts;
	_address = address;
	_name   = name;
	
  setBackground(BACKGROUND_COLOR);  
	
	Label aLabel = new Label(_address,Label.CENTER); 
	
	this.add(aLabel);
  Label nLabel = new Label(_name,Label.CENTER); 
  
  this.add(nLabel);
	
	String status = "?";
	try {
      // create a template to indicate what we are interested in
    Tuple match = new Tuple("X10Status",address,            
              new Field(String.class)  );
        // place ourselves on the list to notified when anyone anywhere
        // writes a matching Tuple to this TupleSpace.            
    int seqNum = _ts.eventRegister(TupleSpace.WRITE,match, this);
 

		Tuple template = new Tuple("X10Status",_address,new Field(String.class));
		Tuple statusTuple = ts.read(template);
		if (statusTuple != null) {
			status = (String)statusTuple.getField(2).getValue();
		}
	} catch (Exception e) {
		Debug.out(e);
	}
	_statusLabel = new Label("Status: "+status,Label.CENTER);
	this.add(_statusLabel);
	
	Panel buttons = new Panel();
	
	Button on = new Button("On");
	on.addActionListener( new ActionListener()  {
        public void 
        actionPerformed(ActionEvent e) {
          X10DevicePanel.this.on("On");              
        }
      } );

	Button off = new Button("Off");
	off.addActionListener( new ActionListener()  {
        public void 
        actionPerformed(ActionEvent e) {
          X10DevicePanel.this.on("Off");              
        }
      } );

	buttons.setLayout(new FlowLayout());
	buttons.add(on);
	buttons.add(off);
	this.add(buttons);
} // X10DevicePanel

void
on(String setting) {
	Debug.out("on="+setting);
	try {
    Tuple tuple = new Tuple("X10Command",_address,setting);
    Debug.out(tuple);
    _ts.write(tuple);
	} catch (Exception e) {
		Debug.out(e);
	}
	
}

void
setStatus(String status) {
  _statusLabel.setText(status);	
}
		
  /*
    ***************************************************************************
    ** ** call **
    ** **********
    */
    /**
    ** Process the callback from the server that notifies us when anyone 
    ** (including ourselfes) writes to the X10 TupleSpace.
    
    ** @param eventName_ the name of the event command that caused this call, that is the
    ** name of the client side command of the thread that registered this call, e.g., in the
    ** case of a read, this would be TupleSpace.READ, **not** TupleSpace.WRITE which is the
    ** corresponding command that caused the actaul event.
    ** @param tsName_ the name of the tuple space this command was executed on.
    ** @param sequenceNumber_ the sequenceNumber for this event/command
    ** @param tuple_ the returned tuple or a Tuple with an exception inside
    ** @param isException_ was the command processed normaly or was there an exception
    **
    ** @return true if this is the last call this sequence # should be getting otherwise false
    *************************************************************************** 
    */
    public synchronized boolean 
    call(String eventName_, String tsName_, int sequenceNumber_, SuperTuple tuple_, 
                    boolean isException_) {
        
   
    try {
      if (! isException_) {
        String status = (String)(tuple_.getField(2).getValue());
        setStatus(status);
      }
     }  catch(TupleSpaceException tse) {
       Debug.out(tse);
     } // catch
       
     return false;
 } // call
		
		
		
} // end class X10DevicePanel

/*
$History: X10DevicePanel.java $
 * 
 * *****************  Version 2  *****************
 * User: Jthomas      Date: 3/17/99    Time: 6:07p
 * Updated in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/x10
 * 
 * *****************  Version 1  *****************
 * User: Jthomas      Date: 2/03/99    Time: 10:58a
 * Created in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/x10
 
*/
/* $Log: X10DevicePanel.java,v $
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:54  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.3  1999/11/03 16:09:13  jthomas
 * Minor cleanup while testing with Jeode
 *
 * Revision 1.2  1999/06/17 05:39:48  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



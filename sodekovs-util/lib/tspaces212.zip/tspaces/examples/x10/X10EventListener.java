// X10EventListener.java

package com.ibm.tspaces.examples.x10;


// OEM Certified:  jthomas, Jan 30, 1999
/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
*/

import com.ibm.tspaces.*;

import java.util.*;
/**
** Event Listener interface.
**
** Defines the actionPerformed method
*/
public interface X10EventListener 
		extends java.util.EventListener  {
			
				
 

  /**
  ** Called for X10  events.
  ** 
  ** This will be called for any of the following X10 events
  **  X10Event.DEVICE_DEFINE - 
  **      Identify event sent when an X10 device sends a response
  **      indicating that a function was performed.
  **  X10Event.DEVICE_FUNCTION
  **      Identify an X10 function that has been invoked 
  **      like "A1 On"
  **      The Function code can be obtained via getFunction()
  **      The X10Device object is referenced by getDevice() 
  */ 

  
public void 
functionPerformed ( X10Event x10e );	

} // end X10EventListener				
/* $Log: X10EventListener.java,v $
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:49  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



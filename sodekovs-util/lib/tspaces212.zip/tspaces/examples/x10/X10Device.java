// X10Device.java

package com.ibm.tspaces.examples.x10;


// OEM Certified:  jthomas, Jan 30, 1999
/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
*/

import com.ibm.tspaces.*;
import java.io.*;

/**
** X10Device represents an X10 Device 
**
** It can be subclassed to support different X10 devices
**
** @see X10
**
** @author  John Thomas
** @version     $Revision: 2.1 $ $Date: 1999/11/05 22:22:40 $
*/
public class X10Device implements Serializable {

	    
  
  /**
  ** Address of the X10 Device
  */
  String     _deviceAddress = null;
	
	/**
	** Name of the X10 Device 
	**
	** If initailly created by the X10 monitor with no human
	** input, the name will be the same as the address.  But 
	** the setName method can be used to assign more meaningfull
	** name like "Bedroom Light"
  */
  String    _deviceName = "";
	
	/**
	** X10 Device Type
	**
	** This should really be done with subclassing 
	** But for now we will do it with codes 
	**
	** Can get/set using the getType/setType methods
	*/
	int   _deviceType = 0;
	
	public static final int  TYPE_LAMP = 1;
	public static final int  TYPE_MOTIONDETEECTOR = 2;
	public static final int  TYPE_LIGHTDETEECTOR = 3;
  public static final int  TYPE_APPLIANCE = 4;

	
	/**
  ** Description of the X10 Device status
  **
  ** Can contain any meaningful info 
  **
  ** The default is to set the status from the
  ** function code that is reported in the 
  ** setFunction method.
  **
  ** Can be set using the setStatus() method and 
  ** retrieved with the getStatus method.  
  */
  String    _deviceStatus = "?";

	String    _deviceDescription = "";
  
  /***********************************************************
  ** X10Device() Constructor **
  ******************************/  
  /**
  ** X10Device constructor - dummy default constructor 
  **   defined as private so it can't be used.
  **   
  */
  private 
  X10Device()  {  
    
  }  // end X10Device() constructor

	
	
  /***********************************************************
  ** X10Device() Constructor **
  ******************************/	
  /**
  ** X10Device constructor 
  **  
  ** 
  ** 
  ** @param monitor Reference to the X10Monitor instance
  ** @param address The address of the X10 device (i.e. "A1"".
  ** 
  */
  public 
  X10Device(String address)  {
  
    	
  	_deviceAddress = address;
  	
  	_deviceName = address;
  	
  	
    
  	
  }  // end X10Device() constructor
	
	
	/***********************************************************
  ** getAddress **
  ******************************/  
  /**
  ** Obtain the device address 
  ** 
  ** @return String
  */
  public String
  getAddress() {
    return _deviceAddress;
  }
	
  /***********************************************************
  ** getType **
  ******************************/  
  /**
  ** Obtain the device type 
  ** 
  ** @return int 
  **    TYPE_LAMP
  **    TYPE_MOTIONDETECTOR
  **    TYPE_LIGHTDETECTOR
  **    TYPE_APPLIANCE
  */
  public int
  getType() {
    return _deviceType;
  }

	/***********************************************************
  ** setName **
  ******************************/  
  /**
  ** set the Devive Name 
  ** 
  ** @param name  Name of the device
  ** @return void
  */
  public void
  setName(String name) {
    _deviceName = name;
  }
  
	/***********************************************************
  ** setDescription **
  ******************************/  
  /**
  ** set the Device Description string 
  ** 
  ** @param name  text
  */
  public void
  setDescription(String name) {
    _deviceName = name;
  }
  
	/***********************************************************
  ** isFunctionSupported **
  ******************************/  
  /**
  ** return true if the specified function is supported 
  ** 
  **
  ** @param  X10 FunctionCode 
  ** @return  false since by default no commands are supported
  */
  public boolean
  isFunctionSupported(byte functioncode) {
    
     return false;
   
  }

  /***********************************************************
  ** getFunctionBytes **
  ******************************/  
  /**
  ** return the {bytearray} that will do the specified 
  ** function.  It will return null if function is not supported
  **
  ** @param   
  ** @return function as an array of bytes. Null if not supported
  */
  public byte[] 
  getFunctionBytes(byte functioncode) {
    
  	return null;
  	
  	
    
  }

	
	/***********************************************************
  ** setFunction **
  ******************************/  
  /**
  ** set the Device Status  string by examining the 
  ** FunctionCode that is being reported.
  ** 
  ** This needs to be expanded to support extended functions
  ** 
  ** @param function is an array of bytes.
  */
  public void
  setFunction(byte[] function) {
  	
  	int f = 0;
  	if ( function.length == 1) 
  		f = function[0] & 0x0f;
  	else
      f = function[1] & 0x0f; 
  	setStatus(X10.FUNCTION_NAMES[f]);
  	
  }

	/***********************************************************
  ** setStatus **
  ******************************/  
  /**
  ** set the Device Status  string 
  ** This would be things like "On" "Off" etc.
  ** 
  ** @param status - string describing the status .
  */
  public void
  setStatus(String status) {
    _deviceStatus = status;
    
  }

	
	
	/***********************************************************
  ** getName **
  ******************************/  
  /**
  ** Obtain the device name 
  ** 
  ** @return String
  */
  public String
  getName() {
    return _deviceName;
  }
  /***********************************************************
  ** getDescription **
  ******************************/  
  /**
  ** Obtain the device description 
  ** 
  ** @return String
  */
  public String
  getDescription() {
    return _deviceDescription;
  }

	/***********************************************************
  ** getStatus **
  ******************************/  
  /**
  ** Obtain the device status 
  ** 
  ** @return String
  */
  public String
  getStatus() {
    return _deviceStatus;
  }

  /***********************************************************
  ** toString **
  ******************************/  
  /**
  ** Enhance toString method  ** 
  ** 
  ** @return String
  */
  public String
  toString() {
  	return "X10Device: " + _deviceAddress + " - " + _deviceName;
  }

  
} // X10Device
/* $Log: X10Device.java,v $
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:48  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



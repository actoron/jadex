// X10Device.java

package com.ibm.tspaces.examples.x10;


// OEM Certified:  jthomas, Jan 30, 1999
/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
*/

import com.ibm.tspaces.*;


/**
** X10Lamp represents an X10 Lamp control 
**
** It is a subclass of X10Device
**
** @see X10Device
**
** @author  John Thomas
** @version     $Revision: 2.1 $ $Date: 1999/11/05 22:22:40 $
*/
public class X10Lamp extends X10Device  {

	    
  
  

	
	
  /***********************************************************
  ** X10Lamp() Constructor **
  ******************************/	
  /**
  ** X10Lamp constructor 
  **  
  **   
  ** @param address The address of the X10 device (i.e. "A1"".
  ** 
  */
  public 
  X10Lamp(String address)  {
    super(address);
    	
  	_deviceType = TYPE_LAMP;
    
  	
  }  // end X10Lamp(address) constructor
	
	
	
  
  /***********************************************************
  ** isFunctionSupported **
  ******************************/  
  /**
  ** return true if the specified function is supported 
  ** 
  **
  ** @param  X10 FunctionCode 
  ** @return  true for _ON, _OFF _DIM _BRIGHT
  */
  public boolean
  isFunctionSupported(byte functioncode) {
    switch (functioncode) {
      case X10._ON: 
      case X10._OFF:        
      case X10._DIM:
      case X10._BRIGHT:        
        return true;
      default:
        return false;
    }
  }
	
  /***********************************************************
  ** getFunctionBytes **
  ******************************/  
  /**
  ** return the {bytearray} that will do the specified 
  ** function.  It will return null if function is not supported
  **
  ** @param   
  ** @return function as an array of bytes. Null if not supported
  */
  public byte[] 
  getFunctionBytes(byte functioncode) {
  	try {
      byte[] bytes = new byte[2];
      bytes[0] = 0x06;
      byte housecode = (byte)(X10.code2Bin(_deviceAddress) & 0xf0);
      switch (functioncode) {
        case X10._ON:
        case X10._OFF:
          bytes[1] = (byte)(housecode|functioncode);
          return bytes;
        case X10._DIM:
        case X10._BRIGHT:
          bytes[0] = (byte)(bytes[0] | 0x40);
          bytes[1] = (byte)(housecode|functioncode);
          return bytes;
        default:
          return null;
      }
    } catch (Exception e) {
    	Debug.out(e);
    	return null;
    }
  	
    
  }

	
	/***********************************************************
  ** setFunction **
  ******************************/  
  /**
  ** set the Device Status  string by examining the 
  ** FunctionCode that is being reported.
  ** 
  ** This needs to be expanded to support extended functions
  ** 
  ** @param function is an array of bytes.
  */
  public void
  setFunction(byte[] function) {
  	
    int f = function[1] & 0x0f; 
  	setStatus(X10.FUNCTION_NAMES[f]);
  	
  }

	

  
} // X10Lamp
/* $Log: X10Lamp.java,v $
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:49  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



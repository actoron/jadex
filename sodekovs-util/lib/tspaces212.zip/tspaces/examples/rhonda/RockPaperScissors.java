// RockPaperScissors.java

package com.ibm.tspaces.examples.rhonda;

import java.awt.*; 
import java.awt.*;
import java.awt.event.*;
import java.awt.datatransfer.*;
import com.ibm.tspaces.*;
/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/
/**
** This class implements the game of Rock-Paper-Scissors using the
** rhonda() TupleSpace primitive. 
**
** The rhonda operator takes a tuple as an argument 
** and atomically swaps with another matching rhonda tuple. 
** That is, if process 1 and process 2 perform rhondas on 
** Tuples that have matching templates, the tuple that is returned to them 
** is the other processes tuple. 
** This is useful for atomic synchronization.
**
** Usage: java RockPaperScissors <your_name> [r|p|s]
**
** @see TupleSpace
** @see TupleSpace#rhonda
** @see Field
** @version $Revision: 2.1.2.1 $ $Date: 2000/01/28 18:19:02 $
** @author Stephen McLaughry
** @author John Thomas
*/

public class RockPaperScissors {


public static void 
main( String argv[] ) {
	boolean _DEBUG = false;
  	String Host = TupleSpace.DEFAULTHOST;
  	int  Port = TupleSpace.DEFAULTPORT;
  	String Id = "Unknown";
  	String RPS = "";
  	// parse the command line args
  	if (argv.length < 2) {
  		usage();
  		System.exit(1);
  	}
	int i = 0;
	while(i < argv.length) {
		String current = argv[i++];
		if ( i == argv.length ) { // Last argument.
			RPS = current;
			break;
		}	
	    if ( current.equals("-D")) {
	    		_DEBUG=true;
	    }
	    if(current.equals("-h")) {   
	    	Host = argv[i++];
	    	continue;
	    }
	    if(current.equals("-p")) { 
	    	try {  
	    		Port = Integer.valueOf(argv[i++]).intValue();
	    	} catch (NumberFormatException nfe) {
	    		System.out.println("Invalid Port specification: " + argv[i-1]);	
	    	}
	    	continue;
	    }
	    // not an option flag.
	    Id = current;
	    
	}
	RPS = RPS.toUpperCase();
	if ( "RPS".indexOf(RPS) == -1) 
		usage();	
	else {	
    System.out.println("You (User " + Id + ") do " + translate(RPS));
    try {
        // Access the TupleSpace that with a name of "rhonda"
        // Create a Tuple describing the configuration so we 
           // can specify that a TSMMDB implementation of TSpaces 
           // is required.
        //Tuple config = new Tuple(new Field(TupleSpace.TSDBTYPE, TupleSpace._DBTYPE_SMALLDB ) );
        Tuple config = new Tuple(new Field(TupleSpace.TSDBTYPE, TupleSpace._DBTYPE_MMDB ) );

           
        TupleSpace ts = new TupleSpace("rhonda",Host,Port,config);
        if (_DEBUG) 
          ts.setDebug(true);
        
        // Issue Rhonda operator 
        //   pass a Tuple template with my Id and choice of R, P, or S
        //   It will return any existing rhonda matching template or wait until
        //   one appears. 
        Tuple otherTuple = ts.rhonda(new Tuple(new Field(Id),new Field(RPS)) );
      
        
        String answer = (String)otherTuple.getField(1).getValue();
        String opponent = (String)otherTuple.getField(0).getValue();

        System.out.println("User " + opponent + " did " + translate(answer));

        if (RPS.equals(answer)) 
          System.out.println("Tie with " + opponent + "!");

        else if ( ( RPS.equals("R") && answer.equals("P") ) ||
               ( RPS.equals("P") && answer.equals("S") ) ||
                 ( RPS.equals("S") && answer.equals("R") )  )
               
          System.out.println( opponent + " beat you!");

        else 
          System.out.println("You beat " + opponent); 
    } catch (TupleSpaceException tse) {
        tse.printStackTrace();
    }
	    
 	}
 	    
  try {
    	Thread.sleep(5000);   
  } catch (InterruptedException ie) {
  }
} // main

public static String 
translate(String rps) {
	if  ( rps.equals("R")) 
		return "Rock";
	else if ( rps.equals("P")) 
		return "Paper";
	else if ( rps.equals("S") )
		return "Scissors";
	else 
		return "?";
}		
public static void 
usage() {
	System.out.println("Usage:");
	System.out.println("  java  com.ibm.tspaces.examples.rhonda.RockPaperScissors  [options] name r|p|s");
	
	System.out.println("      Options:  -h host  -p port");
	System.out.println("Example:");
	System.out.println("  java ...RockPaperScissors  moe S");    
	
} 
} // RockPaperScissors
/* $Log: RockPaperScissors.java,v $
/* Revision 2.1.2.1  2000/01/28 18:19:02  jthomas
/* no message
/*
/* Revision 2.1  1999/11/05 22:22:39  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:40  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



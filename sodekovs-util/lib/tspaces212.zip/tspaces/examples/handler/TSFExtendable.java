// TSFExtendable.java

package com.ibm.tspaces.server.handler;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

import  com.ibm.tspaces.*;
import  com.ibm.tspaces.server.*;



/** 
** This factory implements a basic totally extendable factory. That is you can add whatever
** handlers you want and can attach any factory on top of it.
** Basically it just inherits all this functionality from TSFactory.
**
** Issues: factories should probably have some way of setting the name or augmenting it
** as different instances of an extendable factory may be downloaded to the same space and
** then we should have different names.
** This file was TSFDownloadable in versions 1-2.
**
** @see TSFactory
** @see TSHandler
** @author	Pete Wyckoff
** @version	$Revision: 2.1 $ $Date: 1999/11/05 22:22:43 $
*/

public class TSFExtendable extends TSFactory {

  /*
  ***************************************************************************
  ** ** Members **
  ** *************
  */
  
  /*
  ***************************************************************************
  ** ** constructor **
  ** *****************
  */
  /*
	**
	** @param theTS the tuple space this factory is attached to
	****************************************************************************
	*/
  public TSFExtendable() {
		super();
  }

	/**
	** the name of this factory
	**
	*/
  public static final String	ExtendableF		=	"Extendable Factory";
  

  /*
  ***************************************************************************
  ** ** getName **
  ** *************
  */
  /**
  ** The name of the factory type
  ** @return The name of this type of Factory
  **
  ***************************************************************************
  */
  public String getName() {
  	 return ExtendableF;
  } // getName

	// just leave the rest as the default which allows other factories to attach and handlers
	// to be installed.
} // TSExtendable

/*
$History: TSFExtendable.java $
 * 
 * *****************  Version 1  *****************
 * User: Jthomas      Date: 11/17/98   Time: 10:22a
 * Created in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/server/handler
 * Add for support of downloadable command handlers
 * 
 * *****************  Version 1  *****************
 * User: Toby         Date: 1/23/98    Time: 10:00a
 * Created in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/utility/factories
 * 
 * *****************  Version 3  *****************
 * User: Toby         Date: 10/02/97   Time: 7:11p
 * Updated in $/GCS/Development/bluespaces/Java/com/ibm/bluespaces/utility/factories
 * Big change.  New structure (from ibm.almaden.tuplespace to
 * ibm.bluespaces) and new convention for the package name (was large COM
 * and is now small com).   Fixed up a few deprecated methods.
 * 
 * *****************  Version 1  *****************
 * User: Wyckoff      Date: 7/18/97    Time: 6:40p
 * Created in $/GCS/Development/Java/COM/ibm/almaden/tuplespace/utility/factories
 * factory and handler examples
 * 
 * *****************  Version 2  *****************
 * User: Smclaugh     Date: 7/16/97    Time: 4:25p
 * Updated in $/GCS/Development/Java/COM/ibm/almaden/tuplespace/server/handler
 * New version of API: write, read, take, waitToRead, waitToTake
 * Also new Tuple and Field subclassing and matching.
 * Also changed formal Fields, so can pass null values.
 * 
 * *****************  Version 1  *****************
 * User: Wyckoff      Date: 7/07/97    Time: 11:28a
 * Created in $/GCS/Development/Java/COM/ibm/almaden/tuplespace/server/handler
 * Factory for downloadable handlers
 * 
 * *****************  Version 1  *****************
 * User: Wyckoff      Date: 7/02/97    Time: 5:12p
 * Created in $/GCS/Development/Java/COM/ibm/almaden/tuplespace
 * For downloadable handlers there is an interface and a factory.
*/
/* $Log: TSFExtendable.java,v $
/* Revision 2.1  1999/11/05 22:22:43  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:55  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:40:01  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



// StaleTimestamp.java

package com.ibm.tspaces.examples.handler;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

import  com.ibm.tspaces.*;


/**
** This class demonstrates how to subclass the Field method for exotic 
** matching behavior.  It is used to compare a timestamp in a 
** Tuple template against the Tuples in the database and select all 
** the stale tuples.  
**
** @see Field
** @see TupleSpace
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:38 $
** @author Pete Wyckoff
** @author John Thomas
*/

public class StaleTimestamp extends Field {
  
	/*
	*********************************************************************************
	** ** constructor **
	********************
	*/
	/**
	** construct a StaleTimestamp, only way to do it for now if via a single long
	** @param newval the long
	** @exception TupleSpaceException if there is aproblem creating the field
	**********************************************************************************
	*/
  public StaleTimestamp(long newval) throws TupleSpaceException { 
    super(new Long(newval));
  }

	/*
	*********************************************************************************
	** ** matches **
	****************
	*/
	/**
	** match based on the less than criterion. This Field is used to 
	** select Tuples whose Timestamp is older than the current time.
	** It is important to use this Field value only in the template so 
	** that it be the object that is being compared to the value in the 
	** real tuple. 
	**
	** @param f the other field --- the one that we are checking against
	** @return true if the other fields value is less than this ones 
	**    and the other is a Long
	**********************************************************************************
	*/
  public boolean matches( Field f ) {
    Debug.out(f.getValue().getClass());
  	Debug.out("Test "+((Long)f.getValue()).longValue() +" < "+((Long)getValue()).longValue() );
    
  	if (! (f.getValue() instanceof Long))
      return false;
  	// return true if f.value() is less than this.value()
    return ((Long)f.getValue()).longValue() < ((Long)getValue()).longValue();
  }
} // StaleTimestamp

/*
$History: StaleTimestamp.java $
 * 
 * *****************  Version 2  *****************
 * User: Jthomas      Date: 1/29/99    Time: 9:59a
 * Updated in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/handler
 * new Field methods
 * Debug stuff
 * 
 * *****************  Version 1  *****************
 * User: Jthomas      Date: 11/17/98   Time: 10:13a
 * Created in $/GCS/Development/TSpaces/Java/com/ibm/tspaces/examples/handler
 * Downloadable command handler example
 * 
*/
/* $Log: StaleTimestamp.java,v $
/* Revision 2.1  1999/11/05 22:22:38  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:38  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



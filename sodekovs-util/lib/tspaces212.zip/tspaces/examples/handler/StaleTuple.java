// StaleTuple.java

package com.ibm.tspaces.examples.handler;



/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

import com.ibm.tspaces.*;
import java.io.Serializable;

/**
** A StaleTuple is an ordered sequence of Fields where the 
** first field is a TimeToDie timestamp that is stored at the 
** time that the Tuple is written. This first field is hidden from
** the application.   
** <p>
** For the purposes of this example the 2nd field is a string and
** and is indexed. The 3rd field is also a String but is not indexed. 
** Other applications would define these differently.
**
** @see Tuple
** @see SuperTuple
** @see Field
** @see TupleSpace
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:38 $
** @author Pete Wyckoff
** @author John Thomas
*/

public class StaleTuple extends SubclassableTuple {
	
	private long _TimeToLive = 15*1000;   // Default time to live = N Seconds
	
	
	/*
	***************************************************************************************
	** ** StaleTuple **
	*******************
	*/
	/**
	** constructor with no arguments builds 
	** a template tuple
	**
	*****************************************************************************************
	*/
  public StaleTuple() throws TupleSpaceException {
    super(new Field(Long.class),
          new Field(String.class),
          new Field(String.class));
  }
  /*
  ***************************************************************************************
  ** ** StaleTuple **
  *******************
  */
  /**
  ** constructor with StaleTimestamp specified.  
  ** It will return a template with the timestamp specified
  ** 
  **
  *****************************************************************************************
  */
  public StaleTuple(StaleTimestamp timestamp) throws TupleSpaceException {
    super(timestamp,
        	new Field(String.class),
          new Field(String.class));

  }

	/*
  ***************************************************************************************
  ** ** StaleTuple **
  *******************
  */
  /**
  ** constructor with one String argument builds 
  ** a template tuple to do simple match retrieve based on Field2
  **
  *****************************************************************************************
  */
  public StaleTuple(String key) throws TupleSpaceException {
    super(new Field(Long.class),
          key,
          new Field(String.class));
  }


  /*
	***************************************************************************************
	** ** StaleTuple **
	*******************
	*/
	/**
	** constructor just calls the super tuple constructor
	** @param obj1 an object that will be in a field
	** @param obj2 an object that will be in a field
	*****************************************************************************************
	*/
  public StaleTuple( String key, String data ) throws TupleSpaceException {
    super(new StaleTimestamp(0),new Field("Key",key), data);
  }

 
  
  /** 
  ** 
  ** This method will return the data Field from the tuple.
  **
  ** @return String that contains the "Data" field from Tuple
  */
  public String
  getData()  throws TupleSpaceException {
    
    //  Show how we extract the contents of the 2nd field.
    return (String)this.getField(2).getValue();
  }  
  /** 
  ** 
  ** This method will set the data Field from the tuple.
  **
  ** @param data String that should be placed in the "Data" field of Tuple
  */
  public void
  setData(String data)  throws TupleSpaceException {
    
    Field  f = this.getField(2);
    f.setValue(data);

  }  

 /** 
  **
  ** This method will return the key Field from the tuple.
  **
  ** @return String that contains the "Key" field from Tuple
  */
  public String
  getKey()  throws TupleSpaceException {
    
    //  Show how we extract the contents of the 2nd field.
    return (String)this.getField(1).getValue();
  }  
  /** 
  ** 
  ** This method will set the Key Field from the tuple.
  **
  ** @param key String that should be placed in the "Key" field of Tuple
  */
  public void
  setKey(String key)  throws TupleSpaceException {
    
    Field  f = this.getField(1);
    f.setValue(key);

  }  

 
	
	 /*
  ***************************************************************************************
  ** ** setTimeToLive **
  **********************
  */
  /**
  ** Sets the time to live value
  ** @param timetolive The time in MS that should expire before
  **   the Tuple is elgible for deletion..
  
  *****************************************************************************************
  */
  public void
  setTimeToLive( long time )  {
    _TimeToLive = time;
  }

 /*
  ***************************************************************************************
  ** ** updateExpirationDate **
  *****************************
  */
  /**
  ** Sets the first Field to the date/time stanp when the object is
  ** elgible for deletion.  
  ** <p>
  ** This method is used by the StaleTupleSpaceHandler
  ** to update field 0 when the Write command is invoked
  ** in the server.
  *****************************************************************************************
  */
  public void
  updateExpirationDate( )  throws TupleSpaceException {
    final long timestamp = System.currentTimeMillis();
    long expire = timestamp+_TimeToLive;
  	
    Field  firstField = this.getField(0);
    firstField.setValue(new Long(expire));

  }
}   // End Class Tuple
/* $Log: StaleTuple.java,v $
/* Revision 2.1  1999/11/05 22:22:38  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:38  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



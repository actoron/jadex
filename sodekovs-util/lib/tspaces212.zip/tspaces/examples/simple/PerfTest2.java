// PerfTest1.java

package com.ibm.tspaces.examples.simple;

import  java.util.*;
import  java.text.*;
import  java.io.*;
import  com.ibm.tspaces.*;
import  com.ibm.tspaces.query.*;
import  com.ibm.tspaces.server.*;
/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/
/**
** This class implements a very simple performance test 
** of TupleSpace.
** We will write "num" tuples and then take "num" tuples 
**
** This version of PerfTestx mainly test the relative performance of a space that
** specifies FIFO as a Config option.
**
** @see TupleSpace
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:40 $
** @author John Thomas
*/

public class PerfTest2 {
	
	
  public static void main( String argv[] ) {
  	String  tsName = null;
  	String	host	=	"Local";
	  ConfigTuple	config = null;
    int     num  = 100;
  	
    	try {
	    	
	      config = new ConfigTuple();
        
        tsName = "mmdb";

	      for (int i=0; i< argv.length; i++) {
	      	if (argv[i].equalsIgnoreCase("SMALLDB") ) {	      	  
	      	  tsName = "smalldb";
	      	} else if (argv[i].equals("-D") )
				    Debug.setDebugOn(true);
	      	else if (argv[i].equals("-h") )
	      		host = argv[++i];
          else {
            // if numeric than count
            try {
              num = Integer.parseInt( argv[i] );        
    
            } // try
            catch( NumberFormatException nfe ) {
              // Must be a host name
              host = argv[i];          
      
            } // catch
          }
	      }
	      // Run test with client and server in same Java VM
        if ( host.equals("Local") ) {  
          TSServer ts = new TSServer();
          Thread serverThread = new Thread( ts, "TSServer" );
          serverThread.start();
          Thread.sleep(1000);
          //Debug.setDebugOn(true);
          TupleSpace.setTSCmdImpl("com.ibm.tspaces.TSCmdLocalImpl");
        }
        if (tsName.equals("smalldb")) 
          config.setOption(ConfigTuple.TSDBTYPE, TupleSpace._DBTYPE_SMALLDB );
        else 
          config.setOption(ConfigTuple.TSDBTYPE, TupleSpace._DBTYPE_MMDB );
           
	      System.out.println("Connect to Server "+tsName+"@"+host);
		
	      TupleSpace ts1 = new TupleSpace(tsName+"1",host,config);
        // Turn on FIFO for TS2
        config.setOption(ConfigTuple.FIFO,new Boolean(true));
        TupleSpace ts2 = new TupleSpace(tsName+"F2",host,config);

        ts1.deleteAll();
        ts2.deleteAll();

        
        
        System.out.println("Start test");
	      SuperTuple tup = null;
	
	      long starttime = System.currentTimeMillis();
		    long totaltime;
	      
	
	      // Write test1 - simple tuple with 2 fields
	      Tuple test1;
	      starttime = System.currentTimeMillis();
	      	
	      for (int i=0; i< num; i++) {	      	
          test1 = new Tuple("Test1","#"+i);
	      	ts1.write(test1);
	      
	      }
	      totaltime = System.currentTimeMillis() - starttime;
	      System.out.println(num +" Tuples written to TS.  Time : " + totaltime);
        
        // Write test2 - simple tuple with 2 fields (FIFO specified)
		    Tuple test2 = null;
		    starttime = System.currentTimeMillis();
	      
	      for (int i=0; i< num; i++)  {
          test2 = new Tuple("Test2","#"+i);    	
	      	ts2.write(test2);
        }
	      totaltime = System.currentTimeMillis() - starttime;
	      System.out.println( num +" Tuples written to TS.  Time : " + totaltime);
	
	
	      // Scan what was just written
	      Tuple template1 = new Tuple("Test1",new Field(String.class));
	      	
	      starttime = System.currentTimeMillis();
	      Tuple tupleset = ts1.scan(template1);
	      int cnt = 0;
	      if ( tupleset != null) {
	          for( Enumeration e = tupleset.fields(); e.hasMoreElements(); ) {
	              Field f = (Field)e.nextElement();
	              tup = (Tuple)f.getValue();
                Debug.out(tup);
	              cnt++;
	          }      
	      }
	      	
	      totaltime = System.currentTimeMillis() - starttime;
	      System.out.println(cnt + " Tuples read (scan) from TS2. Time : " + totaltime);
	      
        
        Tuple template2 = new Tuple("Test2",new Field(String.class));
          

		    starttime = System.currentTimeMillis();
		    cnt = 0;
	      tupleset = ts2.scan(template2);
	      if ( tupleset != null) {
	          for( Enumeration e = tupleset.fields(); e.hasMoreElements(); ) {
	              Field f = (Field)e.nextElement();
	              tup = (Tuple)f.getValue();
                Debug.out(tup);
	              cnt++;             
	          }      
	      }
	
	      totaltime = System.currentTimeMillis() - starttime;
	      System.out.println(cnt + " Tuples read(scan) from TS2. Time : " + totaltime);
	      
	      // Measure using take
	      starttime = System.currentTimeMillis();
        
	      for (int i=0; i < num; i++) { 
          Tuple template1t = new Tuple("Test1","#"+i);
          //Tuple template1t = new Tuple("Test1",new Field(String.class));
          //template1t.getField(1).setValue("#"+i);
	      	tup = ts1.take(template1t);
          Debug.out("Taken="+tup);	      
	      }
	      	
	      totaltime = System.currentTimeMillis() - starttime;
	      System.out.println(num +" Tuples taken from TS1. Time : " + totaltime);
	      
		    starttime = System.currentTimeMillis();
	      for (int i=0; i < num; i++) { 
          tup = ts2.take(template2);
          Debug.out("Taken="+tup);
	      	//tup = ts.read(aq);          
          //ts.deleteTupleById(tup.getTupleID());
        }
	      totaltime = System.currentTimeMillis() - starttime;
	      System.out.println(num +" Tuples taken(FIFO) from TS. Time : " + totaltime);
	
	      System.out.println("That's all!");
    } catch(Exception e) {
      	e.printStackTrace();
    }
  }
}  

/*
** $Log: PerfTest2.java,v $
** Revision 2.1  1999/11/05 22:22:40  estesp
** Update revision number to 2.1 on all files
**
** Revision 1.1.1.1  1999/11/05 16:24:53  estesp
** Imported 2.1.0 release into Austin CVS
**
** Revision 1.3  1999/09/08 15:31:37  jthomas
** Make the tests more self checking and easier to run
**
** Revision 1.2  1999/07/09 05:05:02  jthomas
** updated to run with the TSCmdLocalImpl for blinding speed
**
** Revision 1.1  1999/06/20 14:28:14  jthomas
** add fifo version of PerfTest1
**
*/
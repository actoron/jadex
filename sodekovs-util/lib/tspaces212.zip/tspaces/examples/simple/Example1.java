// Example1.java

package com.ibm.tspaces.examples.simple;

import  java.util.*;
import  java.lang.*;
import  java.text.*;
import  java.io.*;
import  com.ibm.tspaces.*;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/
/**
** This class implements a very simple TupleSpace program.
**
**   Create a TupleSpace object for a TupleSpace named "Example1"
**   at the Host specified as the 1st operand. (default localhost)
**   If this space does not already exist, it will be created.
**   
**   Write 3 tuples to "Example1"   
**      "Key1" "Data1"
**      "Key2",999,"Data2"
**      "Key2" "Data2"
**   First we read one of the tuples back by specifing the exact 
**   contents of the tuple.   
**   
**   Next we take (which reads and removes) a tuple which is
**   selected based on the contents of the first field.      
**
**   
** @see TupleSpace
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:39 $
** @author John Thomas
*/

public class Example1 {
	
public static void 
main( String argv[] ) {
  	
  String	host	=	"localhost";
	if (argv.length > 0) 
    host = argv[0];      // if user specified server host
  if ((argv.length > 1) && (argv[1].equals("-D")) ) {
    Debug.setDebugOn(true);
    TupleSpace.setDebug(true);
  }
  try {
    System.out.println("TSpaces Version = " + TupleSpace.getVersion());
		Debug.out("Attempting to open Server Example1@"+host);
		TupleSpace ts = new TupleSpace("Example1",host);
		Tuple tup = null;
		
		// Write 3 tuples to the TupleSpace
		Tuple t1 = new Tuple("Key1","Data1");	
	  ts.write(t1);
	  
    Tuple t2 = new Tuple("Key2",new Integer(999),"Data2");	                       
	  ts.write(t2);
	  
    Tuple t3 = new Tuple("Key2","Data3");
	  ts.write(t3); 	
		
    // Now read a tuple that matches a template  
		Tuple template = new Tuple("Key2",new Field(String.class));
		Tuple tuple = (Tuple)ts.read(template);
		
	
		Debug.out("Tuple read = " + tuple );
    
    // retrieve the data from a field in the Tuple
    String data = (String)tuple.getField(1).getValue();
		if (data.equals("Data3")) 
      Debug.out(0,"Example1 OK");
    else   
      Debug.out(0,"Example1 failed");
		
	
		System.exit(1);
      
  } catch(TupleSpaceException tse) {
	 
      Debug.out(0,tse);	
     
  }
} // end main()
} // end class
  
  /*
  ** $Log: Example1.java,v $
  ** Revision 2.1  1999/11/05 22:22:39  estesp
  ** Update revision number to 2.1 on all files
  **
  ** Revision 1.1.1.1  1999/11/05 16:24:53  estesp
  ** Imported 2.1.0 release into Austin CVS
  **
  ** Revision 1.7  1999/09/08 15:31:37  jthomas
  ** Make the tests more self checking and easier to run
  **
  ** Revision 1.6  1999/07/30 00:50:09  esakki
  ** *** empty log message ***
  **
  ** Revision 1.4  1999/06/20 14:21:00  jthomas
  ** Add cvs log info
  **
  */
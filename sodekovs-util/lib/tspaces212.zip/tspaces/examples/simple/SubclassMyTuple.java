// SubclassMyTuple.java

package com.ibm.tspaces.examples.simple;

import  java.io.*;
import	com.ibm.tspaces.*;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/
/**
** This class demonstrates simple subclassing of SubclassableTuple.
**
** We will define a class "SubclassMyTuple" which defines the tuples that 
** we will be writing to BlueSpaces.  
** 
** @see TupleSpace
** @see SubclassableTuple
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:40 $
** @author John Thomas
*/


class SubclassMyTuple  extends SubclassableTuple 
				implements Serializable {


/** 
** Default constructor will build a template that would retrieve 
** all tuples in the space.
*/
public 
SubclassMyTuple()  throws TupleSpaceException {
    super(new Field(String.class),new Field(String.class));
}
/** 
** Constructor with only key specified  will build a template 
** for retrieving the data 
*/
public 
SubclassMyTuple(String key)  throws TupleSpaceException {
    super(key,new Field(String.class));
}

/** 
** Constructor with both key and data specified will create 
** a Tuple that can be written to BlueSpaces 
*/

public
SubclassMyTuple(String key, String data) throws TupleSpaceException {
	super(key,data);	
}

/** 
** This is an example of defining a mthod within the SublassableTuple 
** that will hide some of the ugly Tuple and Field code.  
** This method will return the data Field from the tuple.
*/
public String
getData()  throws TupleSpaceException {
	
	//  Show how we extract the contents of the 2nd field.
	return (String)this.getField(1).getValue();
}	
public boolean 
matches( SuperTuple t_ ) {
    // This message will show up in the output from the TSServer.
    Debug.out("SubclassMyTuple.matches() called by server!!!!");
    
	return super.matches(t_);
}  // end matches()


} // end class SubclassExample
/* $Log: SubclassMyTuple.java,v $
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.3  1999/10/06 00:55:53  jthomas
 * cleanup the messages displayed on a normal run
 *
 * Revision 1.2  1999/06/17 05:39:47  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */


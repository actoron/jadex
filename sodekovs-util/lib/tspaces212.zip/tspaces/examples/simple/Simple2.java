// Simple2.java

package com.ibm.tspaces.examples.simple;

import  java.util.*;
import  java.text.*;
import  java.io.*;
import  java.awt.*;
import  com.ibm.tspaces.*;

// Simple example to show bug in BlueSpaces
//
// If a Vector (or VectorWithEquals) is written to TupleSpace, then subsequent 
// writes of the same Vector with different contents will be ignored.  
// The only way to get the new contents written to TupleSpace is to reallocate the 
// Vector. 
// Note:
//   This problem has been fixed in the current version of TSpaces.
//   The key is to do a objectstream.reset() when TupleSpace writes the 
//	objects to the the server
//
public class Simple2 implements Callback {
	
public void
init(String host) {
	try {      
	
		TupleSpace ts = new TupleSpace("Simple2",host);
		
		// create a template to indicate what we are interested in
		Tuple match = new Tuple("Key", 
							Field.makeField("com.ibm.tspaces.VectorWithEquals"));
	    // place ourselves on the list to notified when anyone anywhere
	    // writes a matching Tuple to this TupleSpace.    				
		int seqNum = ts.eventRegister(TupleSpace.WRITE,match, this);
		

		// Write 2 tuples to the TupleSpace and compare the results in the callback
		VectorWithEquals v1 = new VectorWithEquals(1);	
		v1.addElement("Test 1");	
		Tuple t = new Tuple("Key",v1);
		ts.write(t);
		
			
		// Uncomenting the following will fix the problem
		//v1 = new VectorWithEquals(1);
		
	
		v1.removeAllElements();
		v1.addElement("Test 2");
		
		// All variation of Tuple allocation fail the same way.	
		//Tuple t2 = new Tuple("Key",v1);	
		//ts.write(t2);
		//ts.write("Key",v1);
		t = new Tuple("Key",v1);
		ts.write(t);

		try {Thread.sleep(10000);} catch (Exception e){}
      
    } catch(TupleSpaceException tse) {
      System.out.println("TupleSpace Exception: " + tse.getMessage());	
      tse.printStackTrace();
    }      
  
}// init

public synchronized boolean 
call(String eventName_, String tsName_, int sequenceNumber_, SuperTuple tuple_, 
										boolean isException_) {

	System.err.println("callback for " + eventName_ 
			 + ", TupleSpace = " + tsName_  
			 + ",Seq #=" + sequenceNumber_  
			 + ",Tuple="  +	 tuple_ 
			 + ", isException=" + isException_);
	return false;
}

	
public static void 
main( String argv[] ) {
  	
  	String	host	=	"localhost";
	if (argv.length > 0) 
      	host = argv[0];      // if user specified server host
    Simple2 test = new Simple2();
    test.init(host);  	
    System.exit(1);
} // main

} // end class Simple2
/* $Log: Simple2.java,v $
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:46  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



// Example4.java

package com.ibm.tspaces.examples.simple;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/

import  java.io.*;
import  com.ibm.tspaces.*;

/**
** This class demonstrates the use of T Spaces to comunicate 
** application defined objects.
**
** We will define a class "Example4Obj" 
**
** Some of the considerations to keep in mind when using your own classes 
** with T Spaces.
**
**   - The class must implememt Serializable !
**       
**   - Identical usrobj.class file must be accessable by both the client 
**     and the Server.  You can use Serialver to partially avoid this problem
**     but that brings up it's own problems.   
** 
**   - Complicated structures can result in very slow performance due to 
**     time spend serializing and deserializing the objects.
**
**   - The object may need an equals() method to implement an
**     application definition of equality.
**
** @see Serializable
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:39 $
** @author John Thomas
*/

class Example4  {
 static String  host  =  "localhost";

public void
init() {
   
  Tuple mytuple = null;
  
  try {
 
    Debug.out("Attempting to open Server Example4@"+host);
  
    TupleSpace ts = new TupleSpace("Example4",host);
    
    Example4Obj obj1 = new Example4Obj("User Object 1");    
    
    ts.write("Key1",obj1);
    
    Example4Obj obj2 = new Example4Obj("User Object 2");
  
    ts.write("Key2",obj2);
  
    // Take a Tuple with a specific "key"
  
    Debug.out("Waiting to take 'Key2' tuple from TS.");
    Tuple template = new Tuple("Key2",new Field(Example4Obj.class) );
    
    mytuple = (Tuple)ts.take(template);
     Debug.out(" Got tuple ............ "+ mytuple);
    if ( mytuple != null) {
      Example4Obj objreturned = (Example4Obj)mytuple.getField(1).getValue();      
      Debug.out("Userdata="+objreturned.getData());      
    } else { 
      Debug.out("No Match");
    }
    // Take a Tuple with a specific User Object
  
    Debug.out("Waiting to take tuple with matching UserObject from TS.");    
    template = new Tuple("Key1",obj1 );

    mytuple = (Tuple)ts.take(template);
    if ( mytuple != null) {
      Example4Obj objreturned = (Example4Obj)mytuple.getField(1).getValue();      
      Debug.out("Userdata="+objreturned.getData());
    } else { 
      Debug.out("No Match");
    }

    ts.cleanup();
    Debug.out(0,"Example4 was successful"); 
  } catch(TupleSpaceException tse) {
    Debug.out("TupleSpace Exception: " + tse.getMessage());  
    tse.printStackTrace();
  }
} // end init()
      
public static void 
main( String argv[] ) {
    

  Example4 me  = new Example4();
  
  
  
  if (argv.length > 0) 
        host = argv[0];      // if user specified server host
    me.init();    
    System.exit(1);
} // end main()
 

} // end class Example4



/* $Log: Example4.java,v $
/* Revision 2.1  1999/11/05 22:22:39  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.5  1999/10/08 02:14:04  jthomas
 * minor debug output change
 *
 * Revision 1.4  1999/07/30 00:50:10  esakki
 * *** empty log message ***
 *
 * Revision 1.2  1999/06/17 05:39:45  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */


// Example4a.java

package com.ibm.tspaces.examples.simple;


/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/
import  java.io.*;
import  com.ibm.tspaces.*;


/**
** This class demonstrates the use of T Spaces to comunicate 
** application defined objects using FieldPS instead of Field
** to specify the field in the Tuple. 
**
** We will define a class "Example4Obj" and send it to the 
** server using FieldPS to hold the value of Example4Obj.
** Under the covers on the client the value of Example3Obj will be serialized
** into an array of bytes and the byte[] value will be sent
** to the server.  Now it does not matter if the server 
** has a class definition for Example4Obj because it only 
** sees the byte[] object.  
** 
** When a client, this one or any other, then reads back the 
** tuple and retrieves the value,  the byte array will 
** automatically be deserialized.  Of course, this means that 
** the client must have a valid version of the Example4Obj class
** available. 
**
** @see FieldPS
** @see Field
** @see Serializable
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:39 $
** @author John Thomas
*/

public class Example4a  {
	static String	host	=	"localhost";
	String tsname = "Example4a";

	
public void
init() {
	
	Tuple mytuple = null;
	
	try {
    
		Debug.out("Attempting to open Server "+tsname+"@"+host);
	  
		TupleSpace ts = new TupleSpace(tsname,host);
		ts.deleteAll();
		
		Example4Obj obj = new Example4Obj("User Object 1");
		//We use the FieldPS subclass to create a
		// PreSerialized object.
		FieldPS f2 = new FieldPS(obj);		
		Debug.out(f2);	
		ts.write("Key1",f2);
		
		// Create another object and use the same FieldPS object
		// It will automatically serialize it		
		obj = new Example4Obj("User Object 2");
		f2.setValue(obj);
		ts.write("Key2",f2);

		
		// Take a Tuple with a specific "key"
		// Note: We still  specify the FieldPS object
		// with the original class in the template.  Required!		
		Tuple template = new Tuple("Key2",new FieldPS(Example4Obj.class) );
		Debug.out(template);
		mytuple = (Tuple)ts.take(template);
		Debug.out(mytuple);
		if ( mytuple != null) {
			Example4Obj objreturned = (Example4Obj)mytuple.getField(1).getValue();
			
			Debug.out("Userdata="+objreturned.getData());
			// Test that the object returned is really equal.
			if (objreturned.equals(obj)) 
		  	Debug.out(Debug.ALWAYS,"Example4a was successful." );
	    else
	      Debug.out(Debug.ALWAYS,"-->> Test failed <<-- Wrong object returned");
		} else 
		  Debug.out(Debug.ALWAYS,"-->> Test failed <<-- No object returned");		
			
		ts.cleanup();
       
  } catch(TupleSpaceException tse) {
      Debug.out(tse);	
      
  }
} // end init()
	    
public static void 
main( String argv[] ) {
  	
  //TupleSpace.setDebug(true); 
  //Debug.setDebugOn(true);
	
	
	if (argv.length > 0) 
      	host = argv[0];      // if user specified server host
	
	Example4a me  = new Example4a();  
  me.init(); 
	
  System.exit(1);
} // end main()
 

} // end class Example4a
/* $Log: Example4a.java,v $
/* Revision 2.1  1999/11/05 22:22:39  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.3  1999/10/08 02:14:04  jthomas
 * minor debug output change
 *
 * Revision 1.2  1999/06/17 05:39:45  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */


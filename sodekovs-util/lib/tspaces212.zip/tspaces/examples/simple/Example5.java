// Example5.java

package com.ibm.tspaces.examples.simple;

import  java.util.*;
import  java.text.*;
import  java.io.*;
import  java.security.Principal;
import  java.security.acl.*;

import  com.ibm.tspaces.*;
import  com.ibm.tspaces.ac.*;
/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
*/
/**
** This class is similar to Example1 but it specifies AccessControl and
** Configuration information when it creates the TupleSpace.
**
**   Create a TupleSpace object for a TupleSpace named "Example5"
**   at the Host specified as the 1st operand. (default localhost)
**     - If this space does not already exist, it will be created.
**     - We will specify that the Space should be made persistant
**     - We will specify the groups/users that can read or write to the
**       space.
**
**   Write 2 tuples to "Example5" that each consists of 2 strings.  
**      "Key1" "Data1"
**      "Key2" "Data2"
**
**   First we read one of the tuples back  This  should work.
**   
**   Next we take (which reads and removes) a tuple which is
**   selected based on the contents of the first field. This 
**   will fail because the user only had Read authority.     
**   
**   It is setup so one can play with different userid and password 
**   combinations by specifing the host, TS name, userid and Passord on the 
**   command line.
**   
** @see TupleSpace
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:39 $
** @author John Thomas
*/

public class Example5 
			implements AclFactory.DefaultPermissions {
	
public static void 
main( String argv[] ) {
  	
  	String	host	=	"localhost";
  	int     port	=   TupleSpace.DEFAULTPORT;
  	String MyTsName = "Example5";
	String MyUserid = TupleSpace._DEFAULT_USER;
	String MyPassword = "";
	if (argv.length == 0) 
		System.out.println("Syntax:  [ -h ServerHost] [-n tsName] userid/password");
	// standard processing of operands
   
  for (int i=0; i< argv.length; i++) {
    if (argv[i].equals("-D") ) {
      Debug.setDebugOn(true);
    } else if (argv[i].equals("-h")) {
      host = argv[++i]; 
    } else if (argv[i].equals("-n")) {
      MyTsName = argv[++i];  
    } else   {
        MyUserid = argv[i];
    	  int n;
    	  if ((n =MyUserid.indexOf('/')) >0 ) {
    	  	MyPassword = MyUserid.substring(n+1);
    	  	MyUserid = MyUserid.substring(0,n);
    	  }
    }
  }

	 
  
  System.out.println("Host="+host+" TSName="+MyTsName+" User="+MyUserid+" Password="+MyPassword);
  TupleSpace ts = null;
	// set the userid and password prior to issuing the exists() method
	TupleSpace.setUserName(MyUserid);
	TupleSpace.setPassword(MyPassword);
  try {
    System.out.println("T Spaces Version = " + TupleSpace.getVersion());
    boolean exists = TupleSpace.exists(MyTsName,host);
    
    if ( exists ) {
      System.out.println("TupleSpace "+MyTsName+" already created.");      
      ts = new TupleSpace(MyTsName,host); 
    } else {
      // Create a Tuple describing the configuration
      System.out.println("TupleSpace "+MyTsName+" being created with "+MyUserid+" as owner.");

      Tuple config = new Tuple();
      config.add( new Field(TupleSpace.PERSISTENCE, new Boolean( true)) );
      
      // Create a Tuple describing the permissions 
      String owner;
      if (MyUserid != null)
        owner = MyUserid;
      else 
        owner = TupleSpace._DEFAULT_USER;
      
      //    Group Users  - Read access 
      //    User anonymous  - No Read Access
      //    User owner      - READ and Write
      // Note:
      //   This will affect only the initial creating of the space.
      //
      AclEntry ae1 = AclFactory.createAclEntry("Users",P_READ);
      AclEntry ae2 = AclFactory.createAclEntry("anonymous",P_READ);
      ae2.setNegativePermissions();
      AclEntry ae3 = AclFactory.createAclEntry(owner,new Permission[] {P_READ,P_WRITE});
      
      Acl myacl = AclFactory.createAcl(
            MyTsName,owner, new AclEntry[] {ae1,ae2,ae3});
      Tuple permission = new Tuple((Serializable)myacl);
    	
    	System.out.println(myacl);
      System.out.println("Attempting to open TupleSpace "+MyTsName+"@"+host);
      // Create the new Space 
      
      ts = new TupleSpace(MyTsName,
                host,TupleSpace.DEFAULTPORT,
                config,permission,  
                MyUserid,MyPassword);
    } // else  
    
    // Write the data.              
    System.out.println("Try Write");
    try {            
      // Write 2 tuples to the TupleSpace
      Tuple t1 = new Tuple("Key1","Data1");  
      ts.write(t1);
      System.out.println("Wrote "+t1);
      Tuple t2 = new Tuple("Key2","Data2");
      ts.write(t2);
      System.out.println("Wrote "+t2);
    } catch (Exception e) {  
      System.out.println("Exception while writing. " + e);
    }
    // Now try to READ it this should work for most users
    try {
      System.out.println("Try Read");
      Tuple template = new Tuple("Key1",new Field(String.class));
      Tuple tuple;
      // Read a tuple. 
      tuple = (Tuple)ts.read(template);
      String data;
          
      System.out.println("Read " + tuple );
    }   catch(TupleSpaceException tse) {
          System.out.println("TupleSpace Read Exception: " + tse.getMessage());  
    }
  
    // Now do a Take, this should fail if this user does not have both Read and Write
    // access.   Or "Take" access 
    
    try { 
      System.out.println("Try take");
      Tuple template = new Tuple("Key2",new Field(String.class));
      Tuple tuple = (Tuple)ts.take(template);
      
      System.out.println("Take " + tuple );
    
    }   catch(TupleSpaceException tse) {
          System.out.println("TupleSpace Take Exception: " + tse.getMessage());  
      
    } 
    
    try { 
      System.out.println("Try destroy()");
    
      ts.destroy();
      if (TupleSpace.exists(MyTsName,host)) {
        Debug.out(0,"Space remains after destroy()");
      }
    }   catch(TupleSpaceException tse) {
          System.out.println("TupleSpace destroy Exception: " + tse.getMessage());  
      
    } 
    TupleSpace.cleanup();
  
    System.exit(1);

      
  } catch(TupleSpaceException tse) {
    System.out.println("TupleSpace Exception: " + tse.getMessage());	
    tse.printStackTrace();
  }      
} // end main
} // end class
/* $Log: Example5.java,v $
/* Revision 2.1  1999/11/05 22:22:39  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.4  1999/07/30 00:50:10  esakki
 * *** empty log message ***
 *
 * Revision 1.2  1999/06/17 05:39:45  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



// Example2.java

package com.ibm.tspaces.examples.simple;

import  java.io.*;
import	com.ibm.tspaces.*;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/


/**
** This class demonstrates simple subclassing of SubclassableTuple.
**
** We will define a class "Example2Tuple" which defines the tuples that 
** we will be writing to TSpaces.   Our class Example2Tuple 
** extends SubclassableTuple which is a form of Tuple object that can
** be extended to implement the desired Tuple behavior.
**
** Refer to Example1.java to see the same code without the use
** of SubclassableTuple.
** 
** Some of the benefits of defining your own SubclassableTuple are:
** -  You can use the constructors to make it easier to define 
**    tuple templates.  For example, you can have
**      template = new SCTuple(key) 
**    instead of 
**      template = new Tuple(key,new Field(String.class)));
**
** -  You can simplify the code to retrieve data from the tuple.
**    For example, you can have 
**      data = sctuple.getData()
**    instead of 
**      data = (String)tuple.getField(1).getValue() 
** 
** But there are some disadvantages also.  Mainly that the server
** must have access to the same version of the class file for 
** the class that extends SubclassableTuple.
** 
** @see TupleSpace
** @see SubclassableTuple
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:39 $
** @author John Thomas
*/

class Example2  {
	static String	host	=	"localhost";

public void
init() {
	
	Example2Tuple mytuple = null;
	
	try {
        
		System.out.println("Attempting to open Server Subclass@"+host);

		TupleSpace ts = new TupleSpace("Subclass",host);
		
		
		// Write 2 tuples to the TupleSpace
		mytuple = new Example2Tuple("Key1","Data1");
		ts.write(mytuple);
		mytuple = new Example2Tuple("Key2","Data2");
		ts.write(mytuple);
	
		// Take a Tuple with a specific "key"
	
		System.out.println("Waiting to take 'Key2' tuple from TS.");
		Example2Tuple template = new Example2Tuple("Key2");
		mytuple = (Example2Tuple)ts.take(template);
		String data = mytuple.getData();
		System.out.println("Data=" + data );
      
    } catch(TupleSpaceException tse) {
      System.out.println("TupleSpace Exception: " + tse.getMessage());	
      tse.printStackTrace();
    }
} // end init()
	    
public static void 
main( String argv[] ) {
  	

	Example2 me  = new Example2();
	
	
	
	if (argv.length > 0) 
      	host = argv[0];      // if user specified server host
    me.init();  	
    System.exit(1);
} // end main()
 

} // end class Example2

/**
** This class demonstrates simple subclassing of SubclassableTuple.
**
** We will define a class "Example2Tuple" which defines the tuples that 
** we will be writing to TSpaces.  
** 
** @see TupleSpace
** @see SubclassableTuple
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:39 $
** @author John Thomas
*/


class Example2Tuple  extends SubclassableTuple 
				implements Serializable {


/** 
** Default constructor will build a template that would retrieve 
** all tuples in the space.
*/
public 
Example2Tuple()  throws TupleSpaceException {
    super(new Field(String.class),new Field(String.class));
}
/** 
** Constructor with only key specified  will build a template 
** for retrieving the data 
*/
public 
Example2Tuple(String key)  throws TupleSpaceException {
    super(key,new Field(String.class));
}

/** 
** Constructor with both key and data specified will create 
** a Tuple that can be written to TSpaces 
*/

public
Example2Tuple(String key, String data) throws TupleSpaceException {
	super(key,data);	
}

/** 
** This is an example of defining a method within the SublassableTuple 
** that will hide some of the ugly Tuple and Field code.  
** This method will return the data Field from the tuple.
*/
public String
getData()  throws TupleSpaceException {
	
	//  Show how we extract the contents of the 2nd field.
	return (String)this.getField(1).getValue();
}

					
/**
** The matches() method will be given control at the server when
** it needs to match a template instance of Example2Tuple with a 
** tuple in the TupleSpace. See SuperTuple.matches() method for a 
** description of the default processing.
**
** @see SuperTuple
** @param t SuperTuple instance in the TupleSpace that we are going to 
** match this template against.
** 
** @returns true if this template matches the instance of 
** Example2Tuple that is in the Tuplespace.
*/
public boolean 
matches( SuperTuple t_ ) {
    // This message will show up in the output from the TSServer
    // if the server has debug messages turned on
    Debug.out("Example2Tuple :" + this + " ?matches? " + t_);
    
	return super.matches(t_);
}  // end matches()

					
/**
** The finalize method will get control when the garbage collector is called
** for this instance.  We have this here just for examining the behavior 
** of the garbage collection .
** Normally we keep this commented out.
*/
protected void
finalize() {
	Debug.out("Example2Tuple.finalize(): " + this );
}
	
} // end class SubclassExample
/* $Log: Example2.java,v $
/* Revision 2.1  1999/11/05 22:22:39  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.7  1999/10/06 00:54:22  jthomas
 * cleanup the messages displayed on a normal run
 *
 * Revision 1.6  1999/07/30 00:50:09  esakki
 * *** empty log message ***
 *
 * Revision 1.2  1999/06/17 05:39:44  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */


// Simple1.java

package com.ibm.tspaces.examples.simple;

import  java.util.*;
import  java.text.*;
import  java.io.*;
import  com.ibm.tspaces.*;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/
/**
** This class implements a very simple TupleSpace program.
**
**   Create a TupleSpace object for a TupleSpace named "Simple1"
**   at the Host specified as the 1st operand. (default localhost)
**      If this space does not already exist, it will be created.
**   
**   Write 2 tuples to "Simple1" that each consists of 2 strings.  
**      "Key1" "Data1"
**      "Key2" "Data2"
**   First we read one of the tuples back by specifing the exact 
**   contents of the tuple.   
**   
**   Next we take (which reads and removes) a tuple which is
**   selected based on the contents of the first field.      
**
**   
** @see TupleSpace
** @version $Revision: 2.1 $ $Date: 1999/11/05 22:22:40 $
** @author John Thomas
*/

public class Simple1 {
	
public static void 
main( String argv[] ) {
  	
  	String	host	=	"localhost";
	if (argv.length > 0) 
      	host = argv[0];      // if user specified server host
    try {
      
		System.out.println("Attempting to open Server Simple1@"+host);
	
		TupleSpace ts = new TupleSpace("Simple1",host);
		Tuple tup = null;
		
		// Write 2 tuples to the TupleSpace
		
		ts.write("Key1","Data1");
		ts.write("Key2","Data2");

		// Read one of the Tuples by specifing the exact contents
		System.out.println("Waiting to read tuple from TS.");
		
		tup = ts.waitToRead("Key1","Data1");
	
		System.out.println("Tuple read was: " + tup );
		
		// WaitToTake a Tuple with a specific "key"
		tup = null;
		System.out.println("Waiting to take 'Key2' tuple from TS.");
		
		tup = ts.waitToTake("Key2",new Field(String.class));
		
		//  Show how we extract the contents of the 2nd field.
		String data = (String)tup.getField(1).getValue();
		System.out.println("Data=" + data );
	
		System.exit(1);

      
    } catch(TupleSpaceException tse) {
      System.out.println("TupleSpace Exception: " + tse.getMessage());	
      tse.printStackTrace();
    }      
  }
}
/* $Log: Simple1.java,v $
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:46  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



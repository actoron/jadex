// tstURLCopy.java

package com.ibm.tspaces.examples.simple;

import  java.util.*;
import  java.net.*;
import  java.io.*;
import  com.ibm.tspaces.*;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/
/**
** This class tests the facility to copy a file from a client and 
** store it at the server where it can be retrieved by other clients

**
**   
** @see TupleSpace
** @version $Revision: 2.1.2.1 $ $Date: 2000/10/18 12:43:28 $
** @author John Thomas
*/

public class tstURLCopy {


public static TupleSpace _ts = null;

static long   starttime;
static long   totaltime;
      
     
static String filestr = "";

static URLCopy copy1 = null;
static URLCopy copy2 = null;

/**
  ***************************************************************************
  ** Test the URLCopy Object.
  **
  ***************************************************************************
  */  
  public static void 
  main( String argv[] ) {
    try {  
      
      
      String tsServerName = "localhost";  
      //   -----------------------------------------------------------------------
      // process command line
      //   -----------------------------------------------------------------------
      Debug.setDebugOn(false);  

      // standard processing of operands
      if ( argv.length == 0) 
        System.out.println("Usage: tstURLCopy [-D] [-h tsHost] filename");
      for (int i=0; i< argv.length; i++) {
        if (argv[i].equals("-D") )
          Debug.setDebugOn(true);
        else if (argv[i].equals("-h")) {
          tsServerName = argv[++i];        
        }
        else 
          filestr = argv[i];
      }
      
      
      Debug.out(0,"Host="+tsServerName);
      if (filestr.length() != 0) 
        Debug.out(0,"File/URL="+filestr);
      else {
        Debug.out(0,"File or URL not specified");
        System.exit(1);
      }
          
      _ts = new TupleSpace("test",tsServerName);
      int currentCnt = _ts.countN(new Tuple());
      if (currentCnt > 0)   {  
        readTest(1);
        _ts.deleteAll();
      }
      writeTest();
      readTest(2);
    } catch(Exception e) {
      Debug.out(Debug.ALWAYS,e);  
  
    }      
    
  }// Main   
      
  
  private static void writeTest()  {
  
   String urlstr = ""; 
   // Now write the Tuples and files to the server
   Debug.out(0,"\n\n*** Write Tuples and File Contents ***\n");
   try  {
   
      URL url1 = null;
      URL url2 = null;
      
      try {
        if (filestr.startsWith("http:") || filestr.startsWith("file:") ) {
          
          urlstr = filestr;      
       
          url1 = new URL(urlstr);
          //url2 = new URL(urlstr2);
        //url = new URL("file:/c:/tree.gif");
        //url = new URL("file:/e:/hg.zip");
        //url = new URL("file:/e:/download/");

          copy1 = new URLCopy(url1);
          copy2 = new URLCopy(url1);  
        } else {
          copy1 = new URLCopy(filestr);
          copy2 = new URLCopy(filestr); 
        }
      
      } catch (Exception e) {
        Debug.out(e);
      }
      
      if (copy1 == null) {
        Debug.out(0,"URLCOPY is null");
        System.exit(1);
      }
        
      

      copy1.setRetention(120);   // elegible for deletion after 2 minutes 
      copy2.setRetention(120);
      

      // Write test1
  
      starttime = System.currentTimeMillis();      
      Debug.out(0,"Write to Server: "+copy1);
      _ts.write("File1",copy1);
      //Debug.out(copy2);
      // make another copy of a different file at the server
      Debug.out(0,"Write to Server: "+copy2);
      _ts.write("File2",copy2);
      // make another copy of the same file at the server
      Debug.out(0,"Write to Server: "+copy1);
      _ts.write("File3",copy1);

      totaltime = System.currentTimeMillis() - starttime;
      Debug.out("Write Time : " + totaltime);
      
      
    } catch(Exception e) {
      Debug.out(Debug.ALWAYS,e);  
  
    }      
    
  }// writeTest   
      
  
  private static void readTest(int number)  {
   boolean keep;
   try  {
      starttime = System.currentTimeMillis();    
      //   -----------------------------------------------------------------------
      //Debug.out("Main:  Client ts.read()");
      //   -----------------------------------------------------------------------
      
      // Now read the tuples back so we can check the status
      // of the files on the server
      Debug.out(0,"\n\n*** Read Tuples and Check file Status ***\n");
      Tuple tuple1 = _ts.read("File1",new Field(URLCopy.class) );
      Debug.out(0,tuple1);
      if (tuple1 != null)  {
        URLCopy clientCopy1 = (URLCopy)tuple1.getField(1).getValue();     

      
        Debug.out(0,"isCopyOK() = " + clientCopy1.isCopyOK() );      
        // read file1 back to client and keep it 
        keep = true;
        String fn = clientCopy1.getFileName();
        clientCopy1.copyToLocal("c:/tmp",keep); 
        File copy = new File("c:/tmp",fn);
        Debug.out("File="+copy+"  "+copy.exists());
        Debug.out(0,"Copied and kept at server: "+clientCopy1);

      
        URL urlS1 = clientCopy1.getServerURL();      
        URL urlL1 = clientCopy1.getURL();       
        Debug.out(0,"getServerURL = "+urlS1+"; getURL = "+urlL1);
   
        // At this point urlL should be "file:/c:/tmp/file.txt"
        Debug.out(0,"Equals test: compare copy to original returns: " +
                (clientCopy1.equals(copy1) ? "true" : "false") );
      }
      Tuple template2 = new Tuple("File2",new Field(URLCopy.class));
      Tuple tuple2 = _ts.read(template2 );
      Debug.out(0,tuple2);
      if (tuple2 != null)  {
        URLCopy clientCopy2 = (URLCopy)tuple2.getField(1).getValue();
      
        // read back file2 and have it deleted at the server
         keep = false;
        clientCopy2.copyToLocal("c:/tmp/",keep);
        Debug.out(0,"Copied and deleted from server: "+clientCopy2);
        URL urlS2 = clientCopy2.getServerURL();
      
        URL urlL2 = clientCopy2.getURL();
        Debug.out(0,"getServerURL = "+urlS2+"; getURL = "+urlL2);
        // remove Tuple since we deleted file
        _ts.delete(template2 );
      }
        
      Tuple tuple3 = _ts.read("File3",new Field(URLCopy.class) );
      Debug.out(0,tuple3);
      URLCopy clientCopy3 = (URLCopy)tuple3.getField(1).getValue();
      
      totaltime = System.currentTimeMillis() - starttime;
      Debug.out("Read Time : " + totaltime);

            
      
      
    } catch(Exception e) {
      Debug.out(Debug.ALWAYS,e);  
  
    }      
    
  }// readTest

	
} // end class
  
  /*
  ** $Log: tstURLCopy.java,v $
  ** Revision 2.1.2.1  2000/10/18 12:43:28  jthomas
  ** no message
  **
  ** Revision 2.1  1999/11/05 22:22:40  estesp
  ** Update revision number to 2.1 on all files
  **
  ** Revision 1.1.1.1  1999/11/05 16:24:53  estesp
  ** Imported 2.1.0 release into Austin CVS
  **
  ** Revision 1.1  1999/10/17 15:37:54  jthomas
  ** New testcase for URLCopy
  **
  
  **
  */
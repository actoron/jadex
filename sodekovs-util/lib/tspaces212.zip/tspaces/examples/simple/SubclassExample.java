// SubclassExample.java

package com.ibm.tspaces.examples.simple;

import  java.io.*;
import	com.ibm.tspaces.*;

/*
**  Licensed Materials - Property of IBM
**
**  (C) COPYRIGHT IBM Corp. 1996, 1997  All rights reserved
**
**  US Government Users Restricted Rights - Use, duplication or
**  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
**
**/


/**
** This class demonstrates simple subclassing of SubclassableTuple.
**
** We will define a class "SubclassMyTuple" which defines the tuples that 
** we will be writing to BlueSpaces.   Our class SubclassMyTuple 
** extends SubclassableTuple which is a form of Tuple object that can
** be extended to implement the desired Tuple behavior.
**
** Refer to the Simple1 example to see the same code without the use
** of SubclassableTuple.
** 
** Some of the benefits of defining your own SubclassableTuple are:
** -  You can use the constructors to make it easier to define 
**    tuple templates.  For example, you can have
**      template = new SCTuple(key) 
**    instead of 
**      template = new Tuple(key,new Field(String.class)));
**
** -  You can simplify the code to retrieve data from the tuple.
**    For example, you can have 
**      data = sctuple.getData()
**    instead of 
**      data = (String)tuple.getField(1).value() 
** 
** But there are some disadvantages also.  Mainly that the server
** must have access to the same version of the class file for 
** the class that extends SubclassableTuple.
** 
** @see TupleSpace
** @see SubclassableTuple
** @version $Revision: 2.1.2.1 $ $Date: 2000/08/30 13:03:06 $
** @author John Thomas
*/

class SubclassExample  {
	static String	host	=	"localhost";

public void
init() {
	
	SubclassMyTuple mytuple = null;
	
	try {
        
		Debug.out("Attempting to open Server Subclass@"+host);
	
		TupleSpace ts = new TupleSpace("Subclass",host);
		
		mytuple = (SubclassMyTuple)ts.read(new SubclassMyTuple("Key1"));
	  if ( mytuple != null)  {
		    Debug.out("Old Tuple read was: " + mytuple );
        // update using TupleID
        TupleID tid0 = mytuple.getTupleID();
        mytuple = (SubclassMyTuple)ts.readTupleById(tid0);
        Debug.out("Tuple readByTupleID was: " + mytuple );
        mytuple = new SubclassMyTuple("Key1","New Updated Data");
        ts.update(tid0,mytuple);
        mytuple = (SubclassMyTuple)ts.waitToRead(new SubclassMyTuple("Key1"));
	
		    Debug.out("Tuple read was: " + mytuple );  
	  }
		// Write 2 tuples to the TupleSpace
		mytuple = new SubclassMyTuple("Key1","Data1");
		TupleID tid1 = ts.write(mytuple);
		mytuple = new SubclassMyTuple("Key2","Data2");
		TupleID tid2 = ts.write(mytuple);
	

		// Read one of the Tuples by specifing the exact contents
		Debug.out("Waiting to read tuple from TS.");
		
		mytuple = (SubclassMyTuple)ts.waitToRead(new SubclassMyTuple("Key1","Data1"));
	
		Debug.out("Tuple read was: " + mytuple );
		
		// WaitToTake a Tuple with a specific "key"
		mytuple = null;
		Debug.out("Waiting to take 'Key2' tuple from TS.");
		
		mytuple = (SubclassMyTuple)ts.waitToTake(new SubclassMyTuple("Key2"));
		
		Debug.out("Data=" + mytuple.getData() );
    
    // update using TupleID
    mytuple = new SubclassMyTuple("Key1","Updated Data");
    ts.update(tid1,mytuple);
    mytuple = (SubclassMyTuple)ts.waitToRead(new SubclassMyTuple("Key1"));
	
		Debug.out("Tuple read was: " + mytuple ); 
     
    } catch(TupleSpaceException tse) {
      Debug.out(tse);	
      
    }
} // end init()
	    
public static void 
main( String argv[] ) {
  	

	SubclassExample me  = new SubclassExample();
	
	if (argv.length > 0) 
    host = argv[0];      // if user specified server host
  if ((argv.length > 1) && (argv[1].equals("-D")) ) {
    Debug.setDebugOn(true);
    //TupleSpace.setDebug(true);
  }
	
	
    me.init();  	
    System.exit(1);
} // end main()
 

} // end class SubclassExample
/* $Log: SubclassExample.java,v $
/* Revision 2.1.2.1  2000/08/30 13:03:06  jthomas
/* minor changes
/*
/* Revision 2.1  1999/11/05 22:22:40  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.2  1999/06/17 05:39:46  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */



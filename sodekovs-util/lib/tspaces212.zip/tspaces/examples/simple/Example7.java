package com.ibm.tspaces.examples.simple;
     
import com.ibm.tspaces.*;
import java.lang.*;

/**
** This is a basic example of how to use Transactions with TSpaces.
**
*/
public class Example7 {
  
  
  public static void main(String[] argv) {
    
    String host = "localhost";
    if (argv.length > 0) 
      host = argv[0];      // if user specified server host
    if ((argv.length > 1) && (argv[1].equals("-D")) ) {
      Debug.setDebugOn(true);
      //TupleSpace.setDebug(true);
    }
    try {
      Tuple template = new Tuple();
      Tuple results;
      
      
      // Create a couple of TupleSpaces and make sure they are empty
      TupleSpace ts1 = new TupleSpace("Example7",host);
      ts1.deleteAll();
      
      
      TupleSpace ts2 = new TupleSpace("Example7a",host);
      ts2.deleteAll();
      
      // create a Transaction object. 
      Transaction trans = new Transaction();
      // Add the TupleSpaces to the Transaction object
      // This is what connects the Tuplespace to the Transaction
      trans.addTupleSpace(ts1);
      trans.addTupleSpace(ts2);

      // Now write to the TupleSpace.  We have not yet 
      // started a transaction so this is just a standalone 
      // transaction.
      ts1.write(new Tuple("standalone", "before")); 
        
      // Now we start a transaction.    
      trans.beginTrans();
      
      ts1.write(new Tuple("trans1", "commit data1"));
      ts2.write(new Tuple("trans1", "commit data2"));
 
      
      
      // Now commit the transaction so this can be checkpointed
      trans.commitTrans();
      
      // Now start another Transaction 
      trans.beginTrans();
      // Now write something that should disappear
      ts1.write(new Tuple("trans2", "aborted data1"));
      ts2.write(new Tuple("trans2", "aborted data2"));

      // Now we abort this transaction        
      trans.abortTrans();
      
      // Now write to the TupleSpace agian.  We have not 
      // started a new transaction so this is just a standalone 
      // transaction.
      ts1.write(new Tuple("standalone", "after")); 

      // Now just verify that the contents are correct
      results = ts1.scan(template);
      if (results.numberOfFields() != 3) {
        Debug.out(0,"Failed! ts1 results="+results);
        System.exit(1);
      }
      results = ts2.scan(template);
      if (results.numberOfFields() != 1) {
        Debug.out(0,"Failed! ts2 results="+results);
        System.exit(1);
      }

    } catch(TupleSpaceException tse) {
      Debug.out(0,tse);
      System.exit(1);
    }
    Debug.out(0,"Example7 was successful");
  }  // main
  
} // Example7
/* $Log: Example7.java,v $
/* Revision 2.1  1999/11/05 22:22:39  estesp
/* Update revision number to 2.1 on all files
/*
/* Revision 1.1.1.1  1999/11/05 16:24:53  estesp
/* Imported 2.1.0 release into Austin CVS
/*
 * Revision 1.6  1999/10/08 02:14:05  jthomas
 * minor debug output change
 *
 * Revision 1.5  1999/09/08 15:31:37  jthomas
 * Make the tests more self checking and easier to run
 *
 * Revision 1.4  1999/07/30 00:50:11  esakki
 * *** empty log message ***
 *
 * Revision 1.2  1999/06/17 05:39:46  thodes
 *   Updated the inital checkin to append the "Log" field and
 * convert CR/LF to CR (for win/unix interop).
 *
 *   The inital checkin lower-cased directrory names, and omitted
 * many dirs/files that will added later, e.g., MoDAL stuff.
 *
 * All of the above will need to be done to all VSS-to-CVS
 * converted sources.  In summary, in moving from VSS to CVS, do this:
 *  - lower-case dir names
 *  - CR/LF --> CR
 *  - append CVS "Log" entties
 *
 * (a script that helps with #2 and #3 is in
 *     tspaces1:~thodes/bin/update-keywords.sh)
 * 
 */
